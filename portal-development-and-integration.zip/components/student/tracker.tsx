'use client'

import { useState } from 'react'
import { AppStatusBadge, PageHeader } from '@/components/shared'
import { applications, formatDate, internships, type AppStatus } from '@/lib/data'
import type { View } from '@/components/app-shell'
import { cn } from '@/lib/utils'

const statuses: AppStatus[] = ['Saved', 'Applied', 'Interview', 'Selected', 'Rejected', 'Withdrawn']

export function Tracker({ navigate }: { navigate: (v: View) => void }) {
  const [filter, setFilter] = useState<AppStatus | 'All'>('All')
  const rows = applications.filter((a) => filter === 'All' || a.status === filter)

  return (
    <>
      <PageHeader title="Application Tracker" description="Every internship you saved or applied to, in one place." />

      <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
        {statuses.map((s) => {
          const count = applications.filter((a) => a.status === s).length
          return (
            <button
              key={s}
              onClick={() => setFilter(filter === s ? 'All' : s)}
              aria-pressed={filter === s}
              className={cn('rounded-xl border bg-card p-3 text-left transition-colors hover:border-primary/40', filter === s && 'border-primary ring-2 ring-primary/15')}
            >
              <p className="text-xl font-semibold tabular-nums">{count}</p>
              <p className="text-xs text-muted-foreground">{s}</p>
            </button>
          )
        })}
      </div>

      <div className="overflow-hidden rounded-xl border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-left text-xs text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Internship</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="hidden px-4 py-3 font-medium md:table-cell">Latest update</th>
                <th className="px-4 py-3 font-medium">Updated</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((a) => {
                const i = internships.find((x) => x.id === a.internshipId)!
                return (
                  <tr key={a.id} className="border-t hover:bg-muted/40">
                    <td className="px-4 py-3">
                      <button onClick={() => navigate({ name: 'internship', id: i.id })} className="text-left">
                        <span className="block font-medium hover:text-primary">{i.role}</span>
                        <span className="block text-xs text-muted-foreground">{i.company}</span>
                      </button>
                    </td>
                    <td className="px-4 py-3"><AppStatusBadge status={a.status} /></td>
                    <td className="hidden px-4 py-3 text-muted-foreground md:table-cell">{a.note}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">{formatDate(a.updated)}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        {rows.length === 0 && <p className="p-8 text-center text-sm text-muted-foreground">No applications with this status.</p>}
      </div>
    </>
  )
}
