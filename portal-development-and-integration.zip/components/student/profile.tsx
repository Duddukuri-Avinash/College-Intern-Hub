'use client'

import { useEffect, useRef, useState, type ChangeEvent, type ReactNode } from 'react'
import {
  Award,
  BadgeCheck,
  Briefcase,
  CalendarDays,
  Download,
  FileText,
  FolderGit2,
  Code2,
  GraduationCap,
  Link2,
  Mail,
  MapPin,
  Phone,
  Trophy,
  Upload,
  UserRoundPen,
  User,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Bar, Chip, Panel, VerifyBadge } from '@/components/shared'
import { applications, COLLEGE, formatDate, myInternships, student } from '@/lib/data'
import type { View } from '@/components/app-shell'

const ACCEPTED_TYPES = [
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]
const MAX_RESUME_BYTES = 5 * 1024 * 1024

function InfoRow({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg bg-accent text-primary [&_svg]:size-4" aria-hidden="true">
        {icon}
      </span>
      <div className="min-w-0">
        <dt className="text-xs text-muted-foreground">{label}</dt>
        <dd className="break-words text-sm font-medium">{value}</dd>
      </div>
    </div>
  )
}

function Fact({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex flex-col gap-0.5 rounded-lg bg-muted/60 px-3 py-2">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-sm font-semibold tabular-nums">{value}</span>
    </div>
  )
}

export function StudentProfile({ navigate }: { navigate: (v: View) => void }) {
  const maxSgpa = 10
  const selected = applications.filter((a) => a.status === 'Selected').length
  const completed = myInternships.filter((m) => m.certificateStatus === 'Verified').length
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [resume, setResume] = useState<{ name: string; updated: string; size?: string; url?: string }>({
    name: student.resume,
    updated: student.resumeUpdated,
  })

  useEffect(() => {
    return () => {
      if (resume.url) URL.revokeObjectURL(resume.url)
    }
  }, [resume.url])

  function handleResumeChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!ACCEPTED_TYPES.includes(file.type)) {
      toast.error('Please upload a PDF or DOCX file')
      return
    }
    if (file.size > MAX_RESUME_BYTES) {
      toast.error('File is too large. Maximum size is 5 MB')
      return
    }
    setResume({
      name: file.name,
      updated: new Date().toISOString(),
      size:
        file.size >= 1024 * 1024
          ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
          : `${Math.max(1, Math.round(file.size / 1024))} KB`,
      url: URL.createObjectURL(file),
    })
    toast.success('Resume uploaded', { description: file.name })
  }

  function handleDownload() {
    if (!resume.url) {
      toast.info('Upload a resume first to download it')
      return
    }
    const link = document.createElement('a')
    link.href = resume.url
    link.download = resume.name
    link.click()
  }

  return (
    <>
      <section className="overflow-hidden rounded-2xl border bg-card shadow-xs">
        <div className="h-24 bg-primary sm:h-28" />
        <div className="flex flex-col gap-4 px-5 pb-5 sm:flex-row sm:items-end sm:justify-between sm:px-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <span
              className="-mt-12 flex size-24 items-center justify-center rounded-2xl border-4 border-card bg-accent text-3xl font-semibold text-primary shadow-sm"
              aria-hidden="true"
            >
              {student.initials}
            </span>
            <div>
              <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
                {student.name}
                <BadgeCheck className="size-5 text-success" aria-label="Verified student" />
              </h1>
              <p className="text-sm text-muted-foreground">
                {student.regNo} · {student.degree}
              </p>
              <p className="text-xs text-muted-foreground">{COLLEGE.name}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={handleDownload}>
              <Download /> Resume
            </Button>
            <Button onClick={() => navigate({ name: 'onboarding' })}>
              <UserRoundPen /> Edit Profile
            </Button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 border-t px-5 py-4 sm:grid-cols-3 sm:px-6 lg:grid-cols-6">
          <Fact label="Branch" value={student.branch} />
          <Fact label="Year / Sem" value={`${student.year} / ${student.semester}`} />
          <Fact label="Section" value={student.section} />
          <Fact label="Batch" value={student.batch} />
          <Fact label="CGPA" value={student.cgpa.toFixed(1)} />
          <Fact label="Internships" value={`${completed} done · ${selected} offer`} />
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="flex flex-col gap-6 lg:col-span-1">
          <Panel title="Profile Strength">
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-semibold tabular-nums">{student.profileCompletion}%</span>
              <span className="text-xs text-muted-foreground">Readiness {student.readiness}%</span>
            </div>
            <Bar value={student.profileCompletion} className="mt-3" />
            <ul className="mt-4 flex flex-col gap-1.5 text-xs text-muted-foreground">
              <li>Add 2 more projects to reach 90%</li>
              <li>Upload a verified internship certificate</li>
            </ul>
          </Panel>

          <Panel title="Personal Details">
            <dl className="flex flex-col gap-4">
              <InfoRow icon={<Mail />} label="College email" value={student.email} />
              <InfoRow icon={<Phone />} label="Phone" value={student.phone} />
              <InfoRow icon={<CalendarDays />} label="Date of birth" value={formatDate(student.dob)} />
              <InfoRow icon={<User />} label="Gender" value={student.gender} />
              <InfoRow icon={<MapPin />} label="Address" value={student.address} />
              <InfoRow icon={<GraduationCap />} label="Faculty mentor" value={student.mentor} />
            </dl>
          </Panel>

          <Panel title="Links & Documents">
            <ul className="flex flex-col gap-2 text-sm">
              <li>
                <a href={`https://${student.linkedin}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-muted">
                  <Link2 className="size-4 text-primary" aria-hidden="true" />
                  <span className="truncate">{student.linkedin}</span>
                </a>
              </li>
              <li>
                <a href={`https://${student.github}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-muted">
                  <Code2 className="size-4 text-primary" aria-hidden="true" />
                  <span className="truncate">{student.github}</span>
                </a>
              </li>
              <li className="flex flex-col gap-2 rounded-lg border bg-muted/40 px-2 py-2">
                <div className="flex items-center gap-2">
                  <FileText className="size-4 shrink-0 text-primary" aria-hidden="true" />
                  <div className="min-w-0">
                    <p className="truncate font-medium">{resume.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Updated {formatDate(resume.updated)}
                      {resume.size ? ` · ${resume.size}` : ''}
                    </p>
                  </div>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={ACCEPTED_TYPES.join(',')}
                  className="sr-only"
                  aria-label="Upload resume"
                  onChange={handleResumeChange}
                />
                <Button size="sm" variant="outline" className="w-full" onClick={() => fileInputRef.current?.click()}>
                  <Upload /> {resume.url ? 'Replace Resume' : 'Upload New Resume'}
                </Button>
                <p className="text-xs text-muted-foreground">PDF or DOCX, up to 5 MB</p>
              </li>
            </ul>
          </Panel>
        </div>

        <div className="flex flex-col gap-6 lg:col-span-2">
          <Panel title="About">
            <p className="text-pretty text-sm leading-relaxed text-muted-foreground">{student.about}</p>
          </Panel>

          <Panel title="Academic Performance" action={<span className="text-sm text-muted-foreground">CGPA <strong className="text-foreground">{student.cgpa}</strong></span>}>
            <div className="flex h-36 items-end gap-3" role="list" aria-label="Semester SGPA">
              {student.semesters.map((s) => (
                <div key={s.sem} role="listitem" className="flex flex-1 flex-col items-center gap-1.5">
                  <span className="text-xs font-semibold tabular-nums">{s.sgpa}</span>
                  <div className="w-full max-w-14 rounded-t-md bg-primary/85" style={{ height: `${((s.sgpa - 6) / (maxSgpa - 6)) * 100}px` }} />
                  <span className="text-xs text-muted-foreground">Sem {s.sem}</span>
                </div>
              ))}
            </div>
            <div className="mt-5 flex flex-col divide-y">
              {student.education.map((e) => (
                <div key={e.level} className="flex flex-col gap-1 py-3 first:pt-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-sm font-medium">{e.level}</p>
                    <p className="text-xs text-muted-foreground">
                      {e.institution} · {e.period}
                    </p>
                  </div>
                  <span className="text-sm font-semibold tabular-nums">{e.score}</span>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Skills">
            <div className="grid gap-x-6 gap-y-3 sm:grid-cols-2">
              {student.skills.map((s) => (
                <div key={s.name}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="font-medium">{s.name}</span>
                    <span className="tabular-nums text-muted-foreground">{s.level}%</span>
                  </div>
                  <Bar value={s.level} tone={s.level >= 75 ? 'success' : 'primary'} />
                </div>
              ))}
            </div>
          </Panel>

          <Panel
            title="Internships"
            action={
              <Button variant="ghost" size="sm" onClick={() => navigate({ name: 'my-internships' })}>
                View all
              </Button>
            }
          >
            <ul className="flex flex-col gap-3">
              {myInternships.map((m) => (
                <li key={m.id} className="flex flex-col gap-2 rounded-lg border p-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-3">
                    <span className="flex size-9 items-center justify-center rounded-lg bg-accent text-primary">
                      <Briefcase className="size-4" aria-hidden="true" />
                    </span>
                    <div>
                      <p className="text-sm font-medium">
                        {m.role} · {m.company}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {m.period} · Mentor {m.mentor}
                      </p>
                    </div>
                  </div>
                  <VerifyBadge status={m.certificateStatus ?? m.offerStatus} />
                </li>
              ))}
            </ul>
          </Panel>

          <Panel title="Projects">
            <ul className="grid gap-3 sm:grid-cols-2">
              {student.projects.map((p) => (
                <li key={p.title} className="flex flex-col gap-2 rounded-lg border p-4">
                  <p className="flex items-center gap-2 text-sm font-medium">
                    <FolderGit2 className="size-4 text-primary" aria-hidden="true" />
                    {p.title}
                  </p>
                  <p className="text-xs leading-relaxed text-muted-foreground">{p.summary}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {p.tech.map((t) => (
                      <Chip key={t}>{t}</Chip>
                    ))}
                  </div>
                </li>
              ))}
            </ul>
          </Panel>

          <div className="grid gap-6 sm:grid-cols-2">
            <Panel title="Certifications">
              <ul className="flex flex-col gap-3">
                {student.certifications.map((c) => (
                  <li key={c.name} className="flex gap-3">
                    <Award className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                    <div>
                      <p className="text-sm font-medium">{c.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {c.issuer} · {c.year}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </Panel>
            <Panel title="Achievements">
              <ul className="flex flex-col gap-3">
                {student.achievements.map((a) => (
                  <li key={a} className="flex gap-3 text-sm">
                    <Trophy className="mt-0.5 size-4 shrink-0 text-warning" aria-hidden="true" />
                    {a}
                  </li>
                ))}
              </ul>
            </Panel>
          </div>
        </div>
      </div>
    </>
  )
}
