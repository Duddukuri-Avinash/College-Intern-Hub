'use client'

import { useMemo, useState } from 'react'
import { ArrowRight, Check, Flag, Sparkles, Target } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Bar, MatchRing, PageHeader, Panel } from '@/components/shared'
import { internships, student } from '@/lib/data'
import type { View } from '@/components/app-shell'
import { cn } from '@/lib/utils'

type Roadmap = { id: string; role: string; summary: string; steps: { skill: string; why: string }[]; keywords: string[] }

const roadmaps: Roadmap[] = [
  {
    id: 'analyst',
    role: 'Data Analyst',
    summary: 'Turn raw data into dashboards and insights that teams can act on.',
    keywords: ['data analyst', 'power bi', 'pandas', 'sql'],
    steps: [
      { skill: 'Python', why: 'Scripting and data wrangling' },
      { skill: 'SQL', why: 'Query and join business data' },
      { skill: 'Pandas', why: 'Clean and analyse tables' },
      { skill: 'Power BI', why: 'Build dashboards and KPIs' },
      { skill: 'Statistics', why: 'Draw sound conclusions' },
      { skill: 'Data Storytelling', why: 'Present findings to leaders' },
    ],
  },
  {
    id: 'scientist',
    role: 'Data Scientist',
    summary: 'Build predictive models and run experiments on real datasets.',
    keywords: ['machine learning', 'scientist', 'tensorflow', 'pandas'],
    steps: [
      { skill: 'Python', why: 'Primary language for data science' },
      { skill: 'Statistics', why: 'Foundation for modelling' },
      { skill: 'Pandas', why: 'Feature preparation' },
      { skill: 'Machine Learning', why: 'Classical models and evaluation' },
      { skill: 'Deep Learning', why: 'Neural networks for complex data' },
      { skill: 'TensorFlow', why: 'Train and ship models' },
    ],
  },
  {
    id: 'web',
    role: 'Web Developer',
    summary: 'Design and build fast, accessible web applications end to end.',
    keywords: ['frontend', 'react', 'javascript', 'web'],
    steps: [
      { skill: 'HTML & CSS', why: 'Structure and style pages' },
      { skill: 'JavaScript', why: 'Make pages interactive' },
      { skill: 'React', why: 'Component-based interfaces' },
      { skill: 'Node.js', why: 'Server-side JavaScript' },
      { skill: 'MongoDB', why: 'Store application data' },
      { skill: 'Deployment', why: 'Ship and host your app' },
    ],
  },
  {
    id: 'python',
    role: 'Python Developer',
    summary: 'Write clean back-end services and automation in Python.',
    keywords: ['python', 'backend', 'software'],
    steps: [
      { skill: 'Python', why: 'Language fundamentals' },
      { skill: 'OOP', why: 'Structure larger programs' },
      { skill: 'SQL', why: 'Persist and query data' },
      { skill: 'Flask', why: 'Build web APIs' },
      { skill: 'REST APIs', why: 'Design service interfaces' },
      { skill: 'Testing', why: 'Keep code reliable' },
    ],
  },
  {
    id: 'ai',
    role: 'AI / ML Engineer',
    summary: 'Build and deploy machine learning and generative AI features.',
    keywords: ['machine learning', 'ai', 'tensorflow'],
    steps: [
      { skill: 'Python', why: 'Core language for AI work' },
      { skill: 'Machine Learning', why: 'Models and evaluation' },
      { skill: 'Deep Learning', why: 'Neural network basics' },
      { skill: 'NLP', why: 'Work with text data' },
      { skill: 'Generative AI', why: 'LLMs and prompting' },
      { skill: 'MLOps', why: 'Deploy and monitor models' },
    ],
  },
  {
    id: 'cloud',
    role: 'Cloud Engineer',
    summary: 'Run reliable applications on cloud infrastructure.',
    keywords: ['cloud', 'aws', 'devops'],
    steps: [
      { skill: 'Linux', why: 'Command line and servers' },
      { skill: 'Networking', why: 'How services connect' },
      { skill: 'AWS', why: 'Core cloud services' },
      { skill: 'Docker', why: 'Package applications' },
      { skill: 'Kubernetes', why: 'Orchestrate containers' },
      { skill: 'CI/CD', why: 'Automate releases' },
    ],
  },
  {
    id: 'security',
    role: 'Cybersecurity',
    summary: 'Protect systems and data by finding and fixing weaknesses.',
    keywords: ['security', 'cyber'],
    steps: [
      { skill: 'Networking', why: 'Understand traffic and protocols' },
      { skill: 'Linux', why: 'Work in security tooling' },
      { skill: 'Security Fundamentals', why: 'Threats, CIA triad, controls' },
      { skill: 'Cryptography', why: 'Protect data in transit and at rest' },
      { skill: 'Web Security', why: 'OWASP Top 10' },
      { skill: 'Ethical Hacking', why: 'Practise on lab environments' },
    ],
  },
]

const known = new Set(student.skills.map((s) => s.name.toLowerCase()))
// Skills from the certifications on the profile count as known for roadmap purposes.
if (student.certifications.some((c) => /aws/i.test(c.name))) known.add('aws')

type Status = 'completed' | 'current' | 'next' | 'upcoming'

export function SkillRoadmap({ navigate }: { navigate: (v: View) => void }) {
  const [roleId, setRoleId] = useState(roadmaps[0].id)
  const [manual, setManual] = useState<Record<string, string[]>>({})
  const rm = roadmaps.find((r) => r.id === roleId) ?? roadmaps[0]

  const steps = useMemo(() => {
    const doneSet = new Set(manual[rm.id] ?? [])
    const base = rm.steps.map((s) => ({ ...s, done: known.has(s.skill.toLowerCase()) || doneSet.has(s.skill) }))
    let seenCurrent = false
    let seenNext = false
    return base.map((s): typeof s & { status: Status } => {
      if (s.done) return { ...s, status: 'completed' }
      if (!seenCurrent) {
        seenCurrent = true
        return { ...s, status: 'current' }
      }
      if (!seenNext) {
        seenNext = true
        return { ...s, status: 'next' }
      }
      return { ...s, status: 'upcoming' }
    })
  }, [rm, manual])

  const completed = steps.filter((s) => s.status === 'completed')
  const current = steps.find((s) => s.status === 'current')
  const next = steps.find((s) => s.status === 'next')
  const pct = Math.round((completed.length / steps.length) * 100)

  const related = useMemo(() => {
    const roadmapSkills = new Set(rm.steps.map((s) => s.skill.toLowerCase()))
    return internships
      .map((i) => {
        const text = `${i.role} ${i.skills.join(' ')}`.toLowerCase()
        const overlap = i.skills.filter((s) => roadmapSkills.has(s.toLowerCase())).length
        const kw = rm.keywords.some((k) => text.includes(k))
        return { i, score: overlap * 2 + (kw ? 1 : 0), overlap }
      })
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3)
  }, [rm])

  function complete(skill: string) {
    setManual((m) => ({ ...m, [rm.id]: [...(m[rm.id] ?? []), skill] }))
    toast.success(`${skill} marked as complete`)
  }

  return (
    <>
      <PageHeader title="Skill Roadmap" description="Pick a role to see the skills to learn, in order, and the internships they open up." />

      <div className="flex flex-wrap gap-2" role="tablist" aria-label="Role roadmaps">
        {roadmaps.map((r) => {
          const active = r.id === roleId
          return (
            <button
              key={r.id}
              role="tab"
              aria-selected={active}
              onClick={() => setRoleId(r.id)}
              className={cn('rounded-lg border px-3 py-1.5 text-sm transition-colors', active ? 'border-primary bg-primary font-medium text-primary-foreground' : 'bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground')}
            >
              {r.role}
            </button>
          )
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="flex flex-col gap-6 lg:col-span-1">
          <Panel title={rm.role}>
            <p className="text-sm text-muted-foreground">{rm.summary}</p>
            <div className="mt-4 flex items-baseline justify-between">
              <span className="text-3xl font-semibold tabular-nums">{pct}%</span>
              <span className="text-xs text-muted-foreground">
                {completed.length} of {steps.length} skills
              </span>
            </div>
            <Bar value={pct} tone={pct === 100 ? 'success' : 'primary'} className="mt-3" />
          </Panel>

          <Panel title="Where you are">
            <dl className="flex flex-col gap-4 text-sm">
              <div className="flex gap-3">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-success/10 text-success">
                  <Check className="size-4" aria-hidden="true" />
                </span>
                <div>
                  <dt className="text-xs text-muted-foreground">Completed</dt>
                  <dd className="font-medium">{completed.length ? completed.map((c) => c.skill).join(', ') : 'None yet'}</dd>
                </div>
              </div>
              <div className="flex gap-3">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-accent text-primary">
                  <Target className="size-4" aria-hidden="true" />
                </span>
                <div>
                  <dt className="text-xs text-muted-foreground">Current skill</dt>
                  <dd className="font-medium">{current?.skill ?? 'All skills complete'}</dd>
                </div>
              </div>
              <div className="flex gap-3">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-warning/15 text-warning-foreground">
                  <Sparkles className="size-4" aria-hidden="true" />
                </span>
                <div>
                  <dt className="text-xs text-muted-foreground">Recommended next</dt>
                  <dd className="font-medium">{next?.skill ?? 'Nothing further'}</dd>
                </div>
              </div>
            </dl>
          </Panel>
        </div>

        <div className="flex flex-col gap-6 lg:col-span-2">
          <Panel title="Learning path">
            <ol className="flex flex-col">
              {steps.map((s, idx) => (
                <li key={s.skill} className="relative flex gap-4 pb-6 last:pb-0">
                  {idx < steps.length - 1 && <span className={cn('absolute left-4 top-8 h-[calc(100%-2rem)] w-0.5 -translate-x-1/2', s.status === 'completed' ? 'bg-success' : 'bg-border')} aria-hidden="true" />}
                  <span
                    className={cn(
                      'relative z-10 flex size-8 shrink-0 items-center justify-center rounded-full border-2 text-xs font-semibold',
                      s.status === 'completed' && 'border-success bg-success text-success-foreground',
                      s.status === 'current' && 'border-primary bg-accent text-primary',
                      s.status === 'next' && 'border-warning bg-warning/15 text-warning-foreground',
                      s.status === 'upcoming' && 'border-border bg-card text-muted-foreground',
                    )}
                    aria-current={s.status === 'current' ? 'step' : undefined}
                  >
                    {s.status === 'completed' ? <Check className="size-4" aria-hidden="true" /> : idx + 1}
                  </span>
                  <div className="flex min-w-0 flex-1 flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                      <p className="flex flex-wrap items-center gap-2 text-sm font-medium">
                        {s.skill}
                        {s.status === 'current' && <span className="rounded-full border border-primary/20 bg-accent px-2 py-0.5 text-xs text-primary">Current</span>}
                        {s.status === 'next' && <span className="rounded-full border border-warning/30 bg-warning/15 px-2 py-0.5 text-xs text-warning-foreground">Recommended next</span>}
                        {s.status === 'completed' && <span className="text-xs font-normal text-success">Completed</span>}
                      </p>
                      <p className="text-xs text-muted-foreground">{s.why}</p>
                    </div>
                    {s.status === 'current' && (
                      <Button size="sm" onClick={() => complete(s.skill)}>
                        <Flag /> Mark complete
                      </Button>
                    )}
                  </div>
                </li>
              ))}
            </ol>
          </Panel>

          <Panel title="Related internships" action={<Button variant="ghost" size="sm" onClick={() => navigate({ name: 'discover' })}>Browse all <ArrowRight /></Button>}>
            {related.length === 0 ? (
              <p className="text-sm text-muted-foreground">No open internships match this role right now. Finish your current skill and check Find Internships again.</p>
            ) : (
              <ul className="flex flex-col gap-3">
                {related.map(({ i, overlap }) => (
                  <li key={i.id}>
                    <button onClick={() => navigate({ name: 'internship', id: i.id })} className="flex w-full items-center gap-3 rounded-lg border p-3 text-left transition-colors hover:border-primary/30 hover:bg-muted/40">
                      <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-sm font-bold text-primary" aria-hidden="true">
                        {i.company.slice(0, 2).toUpperCase()}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium">{i.role}</span>
                        <span className="block truncate text-xs text-muted-foreground">
                          {i.company} · uses {overlap} skill{overlap === 1 ? '' : 's'} from this roadmap
                        </span>
                      </span>
                      <MatchRing value={i.match} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>
      </div>
    </>
  )
}
