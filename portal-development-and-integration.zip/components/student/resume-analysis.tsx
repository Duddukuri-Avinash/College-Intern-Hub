'use client'

import { useEffect, useMemo, useState, type ChangeEvent } from 'react'
import { ArrowRight, Check, FileText, FolderGit2, Info, Lightbulb, Loader2, Route, ThumbsUp, TriangleAlert, Upload, Award, RotateCcw, UserRoundPen } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Bar, Chip, PageHeader, Panel, selectClass } from '@/components/shared'
import { internships, student } from '@/lib/data'
import type { View } from '@/components/app-shell'
import { cn } from '@/lib/utils'

const ACCEPTED = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
const STEPS = ['Reading your resume', 'Detecting skills, projects and certifications', 'Comparing with internship requirements', 'Preparing suggestions']
const REQUIRED_LEVEL = 70
const SCORE_CAP = 95

const gapTargets = internships.filter((i) => ['i4', 'i1', 'i2', 'i5'].includes(i.id))

const breakdown = [
  { label: 'Skills coverage', value: 78 },
  { label: 'Projects', value: 70 },
  { label: 'Certifications', value: 74 },
  { label: 'Keywords & formatting', value: 66 },
]

const strengths = [
  'Strong core programming: Java and Python are listed with real project evidence.',
  'Two hands-on projects with clear outcomes, including one used by 300+ students.',
  'Three relevant certifications across Java, data science and cloud.',
  'Consistent academic record shown with CGPA.',
]

const actions = [
  { id: 'a1', title: 'Learn Power BI basics', detail: 'Appears in 2 of your best-matching internships and is missing from your resume.', points: 4, cta: { label: 'Open roadmap', view: { name: 'roadmap' } as View } },
  { id: 'a2', title: 'Add measurable results to your projects', detail: 'Mention numbers such as users, accuracy or time saved in each project bullet.', points: 3 },
  { id: 'a3', title: 'Add a short professional summary', detail: 'Two lines at the top stating your target role and strongest skills.', points: 2 },
  { id: 'a4', title: 'Link your GitHub and project repositories', detail: 'Recruiters check code. Add repository links next to each project.', points: 3, cta: { label: 'Edit profile', view: { name: 'onboarding' } as View } },
  { id: 'a5', title: 'Build one TensorFlow or Spring Boot mini-project', detail: 'Closes a skill gap that appears in your Swiggy and Infosys matches.', points: 4, cta: { label: 'Open roadmap', view: { name: 'roadmap' } as View } },
]

function ScoreRing({ value }: { value: number }) {
  const tone = value >= 80 ? 'text-success' : value >= 60 ? 'text-warning' : 'text-muted-foreground'
  return (
    <div className="relative flex size-36 shrink-0 items-center justify-center" role="img" aria-label={`Resume readiness score ${value} out of 100`}>
      <svg viewBox="0 0 36 36" className="absolute inset-0 -rotate-90" aria-hidden="true">
        <circle cx="18" cy="18" r="15.5" fill="none" className="stroke-muted" strokeWidth="2.6" />
        <circle cx="18" cy="18" r="15.5" fill="none" className={cn('stroke-current transition-all duration-700', tone)} strokeWidth="2.6" strokeDasharray={`${(value / 100) * 97.4} 97.4`} strokeLinecap="round" />
      </svg>
      <div className="text-center">
        <p className="text-4xl font-semibold tabular-nums">{value}</p>
        <p className="text-xs text-muted-foreground">out of 100</p>
      </div>
    </div>
  )
}

function Disclaimer({ className }: { className?: string }) {
  return (
    <div className={cn('flex items-start gap-3 rounded-xl border border-primary/20 bg-accent p-4 text-sm', className)}>
      <Info className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
      <p className="text-pretty text-accent-foreground">
        This analysis is AI-generated guidance to help you improve your resume. It is not an assessment by any company and does not guarantee shortlisting or selection for any internship.
      </p>
    </div>
  )
}

export function ResumeAnalysis({ navigate }: { navigate: (v: View) => void }) {
  const [stage, setStage] = useState<'upload' | 'analyzing' | 'results'>('upload')
  const [fileName, setFileName] = useState('')
  const [step, setStep] = useState(0)
  const [done, setDone] = useState<string[]>([])
  const [targetId, setTargetId] = useState(gapTargets[0].id)

  useEffect(() => {
    if (stage !== 'analyzing') return
    if (step >= STEPS.length) {
      const t = setTimeout(() => setStage('results'), 400)
      return () => clearTimeout(t)
    }
    const t = setTimeout(() => setStep((s) => s + 1), 750)
    return () => clearTimeout(t)
  }, [stage, step])

  const start = (name: string) => {
    setFileName(name)
    setStep(0)
    setDone([])
    setStage('analyzing')
  }

  function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!ACCEPTED.includes(file.type)) return void toast.error('Please upload a PDF or DOCX file')
    if (file.size > 5 * 1024 * 1024) return void toast.error('File is too large. Maximum size is 5 MB')
    start(file.name)
  }

  const score = Math.min(SCORE_CAP, student.readiness + actions.filter((a) => done.includes(a.id)).reduce((n, a) => n + a.points, 0))
  const label = score >= 80 ? 'Strong foundation' : score >= 65 ? 'Good, with clear gaps to close' : 'Needs work'

  const missing = useMemo(() => [...new Set(internships.filter((i) => i.match >= 70).flatMap((i) => i.missingSkills))], [])
  const target = gapTargets.find((i) => i.id === targetId) ?? gapTargets[0]
  const gap = useMemo(
    () =>
      target.skills.map((name) => {
        const mine = student.skills.find((s) => s.name.toLowerCase() === name.toLowerCase())?.level ?? 0
        const status = mine >= REQUIRED_LEVEL ? 'Ready' : mine > 0 ? 'Gap' : 'Missing'
        return { name, mine, status }
      }),
    [target],
  )
  const coverage = Math.round((gap.filter((g) => g.status === 'Ready').length / gap.length) * 100)

  if (stage === 'upload') {
    return (
      <>
        <PageHeader title="AI Resume Analysis" description="Upload your resume to see how ready it is for internships and what to improve." />
        <Disclaimer />
        <div className="grid gap-6 lg:grid-cols-3">
          <Panel title="Upload resume" className="lg:col-span-2">
            <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-input bg-muted/40 px-4 py-12 text-center transition-colors hover:border-primary/50 hover:bg-accent/50">
              <Upload className="size-8 text-muted-foreground" aria-hidden="true" />
              <span className="text-sm font-medium">Choose a resume to analyse</span>
              <span className="text-xs text-muted-foreground">PDF or DOCX, up to 5 MB</span>
              <input type="file" accept=".pdf,.docx" className="sr-only" aria-label="Upload resume for analysis" onChange={onFile} />
            </label>
            <div className="mt-4 flex flex-col gap-2 rounded-lg border bg-muted/40 p-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2 text-sm">
                <FileText className="size-4 shrink-0 text-primary" aria-hidden="true" />
                <span className="min-w-0 truncate">
                  Use the resume on your profile: <strong className="font-medium">{student.resume}</strong>
                </span>
              </div>
              <Button size="sm" variant="outline" onClick={() => start(student.resume)}>
                Analyse this resume
              </Button>
            </div>
          </Panel>
          <Panel title="What you will get">
            <ul className="flex flex-col gap-3 text-sm text-muted-foreground">
              {['Resume readiness score', 'Detected skills, projects and certifications', 'Strengths and missing skills', 'Skill-gap comparison for a target internship', 'Actions to improve readiness'].map((t) => (
                <li key={t} className="flex gap-2">
                  <Check className="mt-0.5 size-4 shrink-0 text-success" aria-hidden="true" />
                  {t}
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </>
    )
  }

  if (stage === 'analyzing') {
    return (
      <>
        <PageHeader title="AI Resume Analysis" description={`Analysing ${fileName}`} />
        <Panel className="mx-auto w-full max-w-xl">
          <div className="flex items-center gap-3">
            <Loader2 className="size-5 animate-spin text-primary" aria-hidden="true" />
            <p className="font-medium">Analysing your resume…</p>
          </div>
          <Bar value={Math.round((step / STEPS.length) * 100)} className="mt-4" />
          <ol className="mt-5 flex flex-col gap-3" aria-live="polite">
            {STEPS.map((s, i) => (
              <li key={s} className={cn('flex items-center gap-3 text-sm', i < step ? 'text-foreground' : i === step ? 'font-medium text-foreground' : 'text-muted-foreground')}>
                {i < step ? <Check className="size-4 text-success" aria-hidden="true" /> : i === step ? <Loader2 className="size-4 animate-spin text-primary" aria-hidden="true" /> : <span className="size-4 rounded-full border" aria-hidden="true" />}
                {s}
              </li>
            ))}
          </ol>
        </Panel>
      </>
    )
  }

  return (
    <>
      <PageHeader
        title="AI Resume Analysis"
        description={`Results for ${fileName}`}
        actions={
          <Button variant="outline" onClick={() => setStage('upload')}>
            <RotateCcw /> Analyse another resume
          </Button>
        }
      />
      <Disclaimer />

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel title="Resume Readiness Score" className="lg:col-span-1">
          <div className="flex flex-col items-center gap-3 text-center">
            <ScoreRing value={score} />
            <p className="font-medium">{label}</p>
            <p className="text-xs text-muted-foreground">An estimate of how complete and relevant your resume is for internship applications.</p>
          </div>
          <ul className="mt-5 flex flex-col gap-3">
            {breakdown.map((b) => (
              <li key={b.label}>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="text-muted-foreground">{b.label}</span>
                  <span className="font-medium tabular-nums">{b.value}%</span>
                </div>
                <Bar value={b.value} tone={b.value >= 75 ? 'success' : 'primary'} className="h-1.5" />
              </li>
            ))}
          </ul>
        </Panel>

        <div className="flex flex-col gap-6 lg:col-span-2">
          <Panel title="Detected in your resume">
            <div className="flex flex-col gap-5">
              <div>
                <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Skills ({student.skills.length})</p>
                <div className="flex flex-wrap gap-1.5">
                  {student.skills.map((s) => (
                    <Chip key={s.name}>{s.name}</Chip>
                  ))}
                </div>
              </div>
              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Projects ({student.projects.length})</p>
                  <ul className="flex flex-col gap-2">
                    {student.projects.map((p) => (
                      <li key={p.title} className="flex gap-2 text-sm">
                        <FolderGit2 className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                        {p.title}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Certifications ({student.certifications.length})</p>
                  <ul className="flex flex-col gap-2">
                    {student.certifications.map((c) => (
                      <li key={c.name} className="flex gap-2 text-sm">
                        <Award className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                        {c.name}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </Panel>

          <div className="grid gap-6 sm:grid-cols-2">
            <Panel title="Strengths">
              <ul className="flex flex-col gap-3">
                {strengths.map((s) => (
                  <li key={s} className="flex gap-2 text-sm">
                    <ThumbsUp className="mt-0.5 size-4 shrink-0 text-success" aria-hidden="true" />
                    {s}
                  </li>
                ))}
              </ul>
            </Panel>
            <Panel title="Missing skills">
              <p className="mb-3 text-xs text-muted-foreground">Asked for by internships that already match you, but not found in your resume.</p>
              <div className="flex flex-wrap gap-1.5">
                {missing.map((m) => (
                  <span key={m} className="inline-flex items-center gap-1 rounded-md border border-warning/30 bg-warning/15 px-2 py-0.5 text-xs font-medium text-warning-foreground">
                    <TriangleAlert className="size-3" aria-hidden="true" />
                    {m}
                  </span>
                ))}
              </div>
              <Button variant="outline" size="sm" className="mt-4" onClick={() => navigate({ name: 'roadmap' })}>
                <Route /> Plan these on my roadmap
              </Button>
            </Panel>
          </div>
        </div>
      </div>

      <Panel
        title="Internship skill-gap comparison"
        action={
          <select aria-label="Compare against internship" className={cn(selectClass, 'w-auto max-w-64')} value={targetId} onChange={(e) => setTargetId(e.target.value)}>
            {gapTargets.map((i) => (
              <option key={i.id} value={i.id}>
                {i.role} · {i.company}
              </option>
            ))}
          </select>
        }
      >
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="flex flex-col justify-center rounded-lg bg-muted/60 p-4">
            <p className="text-xs text-muted-foreground">Required skills you are ready for</p>
            <p className="mt-1 text-3xl font-semibold tabular-nums">{coverage}%</p>
            <Bar value={coverage} tone={coverage >= 70 ? 'success' : 'primary'} className="mt-3" />
            <p className="mt-3 text-xs text-muted-foreground">Ready means a skill level of {REQUIRED_LEVEL}% or more on your profile.</p>
            <Button size="sm" variant="ghost" className="mt-2 self-start px-0" onClick={() => navigate({ name: 'internship', id: target.id })}>
              View internship <ArrowRight />
            </Button>
          </div>
          <ul className="flex flex-col gap-4 lg:col-span-2">
            {gap.map((g) => (
              <li key={g.name}>
                <div className="mb-1 flex items-center justify-between gap-2 text-sm">
                  <span className="font-medium">{g.name}</span>
                  <span className="flex items-center gap-2 text-xs">
                    <span className="tabular-nums text-muted-foreground">
                      You {g.mine}% · Needed {REQUIRED_LEVEL}%
                    </span>
                    <span
                      className={cn(
                        'rounded-full border px-2 py-0.5 font-medium',
                        g.status === 'Ready' && 'border-success/25 bg-success/10 text-success',
                        g.status === 'Gap' && 'border-warning/30 bg-warning/15 text-warning-foreground',
                        g.status === 'Missing' && 'border-destructive/25 bg-destructive/10 text-destructive',
                      )}
                    >
                      {g.status}
                    </span>
                  </span>
                </div>
                <div className="relative">
                  <Bar value={g.mine} tone={g.status === 'Ready' ? 'success' : g.status === 'Gap' ? 'warning' : 'primary'} />
                  <span className="absolute -top-0.5 h-3 w-0.5 bg-foreground/60" style={{ left: `${REQUIRED_LEVEL}%` }} aria-hidden="true" />
                </div>
              </li>
            ))}
          </ul>
        </div>
      </Panel>

      <Panel title="Improve Readiness" action={<span className="text-xs text-muted-foreground">Estimated gains, capped at {SCORE_CAP}</span>}>
        <ul className="flex flex-col gap-3">
          {actions.map((a) => {
            const isDone = done.includes(a.id)
            return (
              <li key={a.id} className={cn('flex flex-col gap-3 rounded-lg border p-4 sm:flex-row sm:items-center sm:justify-between', isDone && 'bg-success/5')}>
                <div className="flex gap-3">
                  <span className={cn('mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg', isDone ? 'bg-success/10 text-success' : 'bg-accent text-primary')}>
                    {isDone ? <Check className="size-4" aria-hidden="true" /> : <Lightbulb className="size-4" aria-hidden="true" />}
                  </span>
                  <div>
                    <p className={cn('text-sm font-medium', isDone && 'line-through decoration-muted-foreground/50')}>{a.title}</p>
                    <p className="text-xs text-muted-foreground">{a.detail}</p>
                  </div>
                </div>
                <div className="flex shrink-0 flex-wrap items-center gap-2">
                  <span className="text-xs font-medium tabular-nums text-muted-foreground">+{a.points} pts</span>
                  {a.cta && !isDone && (
                    <Button size="sm" variant="outline" onClick={() => navigate(a.cta!.view)}>
                      {a.cta.view.name === 'onboarding' ? <UserRoundPen /> : <Route />} {a.cta.label}
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant={isDone ? 'ghost' : 'default'}
                    onClick={() => {
                      setDone((d) => (d.includes(a.id) ? d.filter((x) => x !== a.id) : [...d, a.id]))
                      if (!isDone) toast.success('Marked as done', { description: 'Score updated. Re-upload your resume to confirm.' })
                    }}
                  >
                    {isDone ? 'Undo' : 'Mark as done'}
                  </Button>
                </div>
              </li>
            )
          })}
        </ul>
      </Panel>
    </>
  )
}
