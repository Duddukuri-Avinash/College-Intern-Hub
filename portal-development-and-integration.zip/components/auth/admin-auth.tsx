'use client'

import { useEffect, useRef, useState, type ReactNode } from 'react'
import { ArrowLeft, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Field } from '@/components/student/form-bits'
import { Heading, PasswordInput, Shell } from '@/components/auth/auth-bits'
import type { AuthScreen } from '@/components/auth/auth-flow'

const ADMIN_ID = /^ADM\d{3}$/i

export function AdminLogin({ setScreen, onPasswordOk, switcher }: { setScreen: (s: AuthScreen) => void; onPasswordOk: () => void; switcher: ReactNode }) {
  const [adminId, setAdminId] = useState('')
  const [password, setPassword] = useState('')
  const [errors, setErrors] = useState<{ id?: string; password?: string }>({})

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const er: typeof errors = {}
    if (!ADMIN_ID.test(adminId.trim())) er.id = 'Use the format ADM001.'
    if (password.length < 6) er.password = 'Enter your admin password.'
    setErrors(er)
    if (Object.keys(er).length) return
    onPasswordOk()
  }

  return (
    <Shell>
      {switcher}
      <Heading title="Admin login" description="Restricted to Training & Placement Cell administrators." />
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <Field label="Admin ID" htmlFor="al-id" error={errors.id}>
          <Input id="al-id" value={adminId} onChange={(e) => setAdminId(e.target.value)} placeholder="e.g. ADM001" autoComplete="username" className="h-9 uppercase placeholder:normal-case" aria-invalid={!!errors.id || undefined} />
        </Field>
        <Field label="Password" htmlFor="al-pw" error={errors.password}>
          <PasswordInput id="al-pw" value={password} onChange={setPassword} autoComplete="current-password" invalid={!!errors.password} />
        </Field>
        <div className="-mt-1 flex justify-end">
          <button type="button" onClick={() => setScreen('forgot')} className="text-xs font-medium text-primary hover:underline">Forgot password?</button>
        </div>
        <Button type="submit" size="lg" className="mt-1 h-9 w-full">Continue</Button>
      </form>
      <div className="mt-6 rounded-lg border border-dashed bg-muted/40 p-3 text-xs text-muted-foreground">
        <p className="font-medium text-foreground">Prototype shortcut</p>
        <p className="mt-0.5">Any Admin ID like ADM001 and a 6+ character password works. Two-step verification accepts any 6 digits.</p>
        <button onClick={onPasswordOk} className="mt-1.5 font-medium text-primary hover:underline">Continue as M. Ravi Kumar (ADM001)</button>
      </div>
    </Shell>
  )
}

export function AdminTwoStep({ setScreen, onVerified }: { setScreen: (s: AuthScreen) => void; onVerified: () => void }) {
  const [code, setCode] = useState('')
  const [error, setError] = useState('')
  const [cooldown, setCooldown] = useState(30)
  const ref = useRef<HTMLInputElement>(null)

  useEffect(() => ref.current?.focus(), [])
  useEffect(() => {
    if (cooldown <= 0) return
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000)
    return () => clearTimeout(t)
  }, [cooldown])

  function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!/^\d{6}$/.test(code)) return setError('Enter the 6-digit code.')
    toast.success('Signed in to the Admin Portal')
    onVerified()
  }

  return (
    <Shell>
      <div className="mb-6 flex flex-col items-center text-center">
        <span className="flex size-14 items-center justify-center rounded-2xl bg-accent text-primary"><ShieldCheck className="size-7" aria-hidden="true" /></span>
        <h1 className="mt-4 text-2xl font-semibold tracking-tight">Two-step verification</h1>
        <p className="mt-1 text-pretty text-sm text-muted-foreground">Enter the 6-digit code sent to ra••••@rvrjc.ac.in.</p>
      </div>
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <Field label="Verification code" htmlFor="tfa-code" error={error}>
          <Input
            ref={ref}
            id="tfa-code"
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={6}
            value={code}
            onChange={(e) => { setCode(e.target.value.replace(/\D/g, '')); setError('') }}
            className="h-11 text-center font-mono text-lg tracking-[0.5em]"
            aria-invalid={!!error || undefined}
          />
        </Field>
        <Button type="submit" size="lg" className="h-9 w-full">Verify and sign in</Button>
        <Button type="button" variant="outline" size="lg" className="h-9 w-full" disabled={cooldown > 0} onClick={() => { setCooldown(30); toast.info('A new code has been sent') }}>
          {cooldown > 0 ? `Resend code in ${cooldown}s` : 'Resend code'}
        </Button>
      </form>
      <button onClick={() => setScreen('login')} className="mt-6 flex w-full items-center justify-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-3.5" /> Back to login
      </button>
    </Shell>
  )
}
