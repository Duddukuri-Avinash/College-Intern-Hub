'use client'

import { useEffect, useState } from 'react'
import { ArrowLeft, CheckCircle2, KeyRound, Mail, MailCheck } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Bar, VerifyBadge } from '@/components/shared'
import { Field } from '@/components/student/form-bits'
import { Heading, PasswordInput, PersonaSwitch, Shell, passwordStrength, type Persona } from '@/components/auth/auth-bits'
import { FacultyLogin, FacultyPending, FacultyRegister, type RegisteredFaculty } from '@/components/auth/faculty-auth'
import { AdminLogin, AdminTwoStep } from '@/components/auth/admin-auth'

export type AuthScreen = 'login' | 'register' | 'verify' | 'forgot' | 'reset' | 'faculty-register' | 'faculty-pending' | 'admin-2fa'

export type RegisteredStudent = {
  name: string
  roll: string
  email: string
  phone: string
  password: string
  verified: boolean
}

const COLLEGE_DOMAIN = '@rvrjc.ac.in'


export function AuthFlow({
  screen,
  setScreen,
  registered,
  setRegistered,
  onLoggedIn,
  onDemo,
  onFacultyLoggedIn,
  onAdminLoggedIn,
}: {
  screen: AuthScreen
  setScreen: (s: AuthScreen) => void
  registered: RegisteredStudent | null
  setRegistered: (r: RegisteredStudent | null) => void
  onLoggedIn: (opts: { firstLogin: boolean }) => void
  onDemo: () => void
  onFacultyLoggedIn: () => void
  onAdminLoggedIn: () => void
}) {
  const [persona, setPersona] = useState<Persona>('student')
  const [faculty, setFaculty] = useState<RegisteredFaculty | null>(null)

  if (screen === 'register') return <Register setScreen={setScreen} setRegistered={setRegistered} />
  if (screen === 'verify') return <Verify setScreen={setScreen} registered={registered} setRegistered={setRegistered} />
  if (screen === 'forgot') return <Forgot setScreen={setScreen} persona={persona} />
  if (screen === 'reset') return <Reset setScreen={setScreen} registered={persona === 'student' ? registered : null} setRegistered={setRegistered} />
  if (screen === 'faculty-register') return <FacultyRegister setScreen={setScreen} setFaculty={setFaculty} />
  if (screen === 'faculty-pending') return <FacultyPending setScreen={setScreen} faculty={faculty} setFaculty={setFaculty} />
  if (screen === 'admin-2fa') return <AdminTwoStep setScreen={setScreen} onVerified={onAdminLoggedIn} />
  if (persona === 'admin') return <AdminLogin setScreen={setScreen} onPasswordOk={() => setScreen('admin-2fa')} switcher={<PersonaSwitch persona={persona} onChange={setPersona} />} />
  if (persona === 'faculty') return <FacultyLogin setScreen={setScreen} faculty={faculty} onLoggedIn={onFacultyLoggedIn} switcher={<PersonaSwitch persona={persona} onChange={setPersona} />} />
  return <Login setScreen={setScreen} registered={registered} onLoggedIn={onLoggedIn} onDemo={onDemo} switcher={<PersonaSwitch persona={persona} onChange={setPersona} />} />
}

/* ------------------------------ Login ------------------------------ */

function Login({ setScreen, registered, onLoggedIn, onDemo, switcher }: { setScreen: (s: AuthScreen) => void; registered: RegisteredStudent | null; onLoggedIn: (o: { firstLogin: boolean }) => void; onDemo: () => void; switcher: React.ReactNode }) {
  const [roll, setRoll] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [unverified, setUnverified] = useState(false)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setUnverified(false)
    const r = roll.trim().toUpperCase()
    if (!r || !password) {
      setError('Enter your roll number and password.')
      return
    }
    if (registered && registered.roll === r) {
      if (registered.password !== password) {
        setError('Roll number or password is incorrect.')
        return
      }
      if (!registered.verified) {
        setUnverified(true)
        return
      }
      toast.success('Welcome to InternHub')
      onLoggedIn({ firstLogin: true })
      return
    }
    // Prototype: any other credentials sign in as the demo student.
    toast.success('Signed in')
    onLoggedIn({ firstLogin: false })
  }

  return (
    <Shell>
      {switcher}
      <Heading title="Student login" description="Sign in with your college roll number." />
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <Field label="Roll number" htmlFor="login-roll">
          <Input id="login-roll" value={roll} onChange={(e) => setRoll(e.target.value)} placeholder="e.g. Y23CS042" autoComplete="username" className="h-9 uppercase placeholder:normal-case" />
        </Field>
        <Field label="Password" htmlFor="login-pw">
          <PasswordInput id="login-pw" value={password} onChange={setPassword} autoComplete="current-password" />
        </Field>
        <div className="-mt-1 flex justify-end">
          <button type="button" onClick={() => setScreen('forgot')} className="text-xs font-medium text-primary hover:underline">
            Forgot password?
          </button>
        </div>

        {error && (
          <p className="rounded-lg border border-destructive/25 bg-destructive/10 px-3 py-2 text-sm text-destructive" role="alert">
            {error}
          </p>
        )}
        {unverified && (
          <div className="flex flex-col gap-2 rounded-lg border border-warning/30 bg-warning/15 p-3 text-sm text-warning-foreground" role="alert">
            <p className="font-medium">College email not verified</p>
            <p className="text-xs">Verify {registered?.email} before signing in.</p>
            <Button type="button" size="sm" variant="outline" className="self-start" onClick={() => setScreen('verify')}>
              <Mail /> Go to verification
            </Button>
          </div>
        )}

        <Button type="submit" size="lg" className="mt-1 h-9 w-full">
          Sign in
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-muted-foreground">
        New to InternHub?{' '}
        <button onClick={() => setScreen('register')} className="font-medium text-primary hover:underline">
          Create your account
        </button>
      </p>

      <div className="mt-6 rounded-lg border border-dashed bg-muted/40 p-3 text-xs text-muted-foreground">
        <p className="font-medium text-foreground">Prototype shortcut</p>
        <p className="mt-0.5">Any other roll number and password signs in as the demo student.</p>
        <button onClick={onDemo} className="mt-1.5 font-medium text-primary hover:underline">
          Continue as Ananya Reddy (Y23CS042)
        </button>
      </div>
    </Shell>
  )
}

/* ---------------------------- Registration ---------------------------- */

function Register({ setScreen, setRegistered }: { setScreen: (s: AuthScreen) => void; setRegistered: (r: RegisteredStudent | null) => void }) {
  const [f, setF] = useState({ name: '', roll: '', email: '', phone: '', password: '', confirm: '' })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const set = (k: keyof typeof f) => (v: string) => setF((p) => ({ ...p, [k]: v }))
  const strength = passwordStrength(f.password)

  function validate() {
    const e: Record<string, string> = {}
    if (f.name.trim().length < 3) e.name = 'Enter your full name as on college records.'
    if (!/^[A-Za-z]\d{2}[A-Za-z]{2,4}\d{3}$/.test(f.roll.trim())) e.roll = 'Use the format Y23CS042.'
    if (!f.email.trim().toLowerCase().endsWith(COLLEGE_DOMAIN)) e.email = `Use your college email ending with ${COLLEGE_DOMAIN}.`
    if (!/^(\+91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}$/.test(f.phone.trim())) e.phone = 'Enter a valid 10-digit mobile number.'
    if (f.password.length < 8) e.password = 'Use at least 8 characters.'
    if (f.confirm !== f.password) e.confirm = 'Passwords do not match.'
    return e
  }

  function submit(ev: React.FormEvent) {
    ev.preventDefault()
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) return
    setRegistered({ name: f.name.trim(), roll: f.roll.trim().toUpperCase(), email: f.email.trim().toLowerCase(), phone: f.phone.trim(), password: f.password, verified: false })
    setScreen('verify')
  }

  return (
    <Shell>
      <Heading title="Create your student account" description="Use your college details so faculty can verify your records." />
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <Field label="Full name" htmlFor="reg-name" error={errors.name}>
          <Input id="reg-name" value={f.name} onChange={(e) => set('name')(e.target.value)} autoComplete="name" className="h-9" aria-invalid={!!errors.name || undefined} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Roll number" htmlFor="reg-roll" error={errors.roll}>
            <Input id="reg-roll" value={f.roll} onChange={(e) => set('roll')(e.target.value)} placeholder="Y23CS042" className="h-9 uppercase placeholder:normal-case" aria-invalid={!!errors.roll || undefined} />
          </Field>
          <Field label="Phone" htmlFor="reg-phone" error={errors.phone}>
            <Input id="reg-phone" type="tel" value={f.phone} onChange={(e) => set('phone')(e.target.value)} placeholder="98485 21436" autoComplete="tel" className="h-9" aria-invalid={!!errors.phone || undefined} />
          </Field>
        </div>
        <Field label="College email" htmlFor="reg-email" error={errors.email} hint="We will send a verification link to this address.">
          <Input id="reg-email" type="email" value={f.email} onChange={(e) => set('email')(e.target.value)} placeholder={`name${COLLEGE_DOMAIN}`} autoComplete="email" className="h-9" aria-invalid={!!errors.email || undefined} />
        </Field>
        <Field label="Password" htmlFor="reg-pw" error={errors.password}>
          <PasswordInput id="reg-pw" value={f.password} onChange={set('password')} autoComplete="new-password" invalid={!!errors.password} />
          {f.password && (
            <div className="flex items-center gap-3">
              <Bar value={strength.value} tone={strength.tone} className="h-1.5" />
              <span className="w-16 shrink-0 text-right text-xs text-muted-foreground">{strength.label}</span>
            </div>
          )}
        </Field>
        <Field label="Confirm password" htmlFor="reg-confirm" error={errors.confirm}>
          <PasswordInput id="reg-confirm" value={f.confirm} onChange={set('confirm')} autoComplete="new-password" invalid={!!errors.confirm} />
        </Field>
        <Button type="submit" size="lg" className="mt-1 h-9 w-full">
          Create account
        </Button>
      </form>
      <p className="mt-6 text-center text-sm text-muted-foreground">
        Already registered?{' '}
        <button onClick={() => setScreen('login')} className="font-medium text-primary hover:underline">
          Sign in
        </button>
      </p>
    </Shell>
  )
}

/* ------------------------- Email verification ------------------------- */

function Verify({ setScreen, registered, setRegistered }: { setScreen: (s: AuthScreen) => void; registered: RegisteredStudent | null; setRegistered: (r: RegisteredStudent | null) => void }) {
  const [cooldown, setCooldown] = useState(30)

  useEffect(() => {
    if (cooldown <= 0) return
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000)
    return () => clearTimeout(t)
  }, [cooldown])

  if (!registered) {
    return (
      <Shell>
        <Heading title="Nothing to verify" description="Create an account first." />
        <Button onClick={() => setScreen('register')}>Go to registration</Button>
      </Shell>
    )
  }

  const verified = registered.verified

  return (
    <Shell>
      <div className="flex flex-col items-center text-center">
        <span className={`flex size-14 items-center justify-center rounded-2xl ${verified ? 'bg-success/10 text-success' : 'bg-accent text-primary'}`}>
          {verified ? <CheckCircle2 className="size-7" aria-hidden="true" /> : <MailCheck className="size-7" aria-hidden="true" />}
        </span>
        <h1 className="mt-4 text-2xl font-semibold tracking-tight">{verified ? 'Email verified' : 'Verify your college email'}</h1>
        <p className="mt-1 text-pretty text-sm text-muted-foreground">
          {verified ? 'Your college email is confirmed. You can sign in now.' : 'We sent a verification link to'}
        </p>
        <p className="mt-0.5 break-all text-sm font-medium">{registered.email}</p>
        <div className="mt-3">
          <VerifyBadge status={verified ? 'Verified' : 'Pending'} />
        </div>
      </div>

      {verified ? (
        <Button size="lg" className="mt-6 h-9 w-full" onClick={() => setScreen('login')}>
          Continue to login
        </Button>
      ) : (
        <div className="mt-6 flex flex-col gap-3">
          <Button
            size="lg"
            className="h-9 w-full"
            onClick={() => {
              setRegistered({ ...registered, verified: true })
              toast.success('College email verified')
            }}
          >
            <Mail /> I have clicked the link (simulate)
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="h-9 w-full"
            disabled={cooldown > 0}
            onClick={() => {
              setCooldown(30)
              toast.info('Verification email resent')
            }}
          >
            {cooldown > 0 ? `Resend email in ${cooldown}s` : 'Resend verification email'}
          </Button>
          <p className="text-center text-xs text-muted-foreground">Check your spam folder if you cannot find it. The link expires in 24 hours.</p>
        </div>
      )}

      <button onClick={() => setScreen('login')} className="mt-6 flex w-full items-center justify-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-3.5" /> Back to login
      </button>
    </Shell>
  )
}

/* ---------------------------- Forgot / Reset ---------------------------- */

function Forgot({ setScreen, persona }: { setScreen: (s: AuthScreen) => void; persona: Persona }) {
  const [id, setId] = useState('')
  const [error, setError] = useState('')
  const [sent, setSent] = useState(false)
  const idLabel = persona === 'faculty' ? 'employee ID' : persona === 'admin' ? 'admin ID' : 'roll number'

  function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!id.trim()) {
      setError(`Enter your ${idLabel} or college email.`)
      return
    }
    setError('')
    setSent(true)
  }

  if (sent) {
    return (
      <Shell>
        <div className="flex flex-col items-center text-center">
          <span className="flex size-14 items-center justify-center rounded-2xl bg-accent text-primary">
            <MailCheck className="size-7" aria-hidden="true" />
          </span>
          <h1 className="mt-4 text-2xl font-semibold tracking-tight">Check your email</h1>
          <p className="mt-1 text-pretty text-sm text-muted-foreground">If an account exists for that {idLabel} or email, a reset link has been sent to the registered college email.</p>
        </div>
        <Button size="lg" className="mt-6 h-9 w-full" onClick={() => setScreen('reset')}>
          <KeyRound /> Open reset link (simulate)
        </Button>
        <button onClick={() => setScreen('login')} className="mt-4 flex w-full items-center justify-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="size-3.5" /> Back to login
        </button>
      </Shell>
    )
  }

  return (
    <Shell>
      <Heading title="Forgot password" description={`Enter your ${idLabel} or college email and we will send a reset link.`} />
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <Field label={persona === 'faculty' ? 'Employee ID or college email' : persona === 'admin' ? 'Admin ID or college email' : 'Roll number or college email'} htmlFor="fp-id" error={error}>
          <Input id="fp-id" value={id} onChange={(e) => setId(e.target.value)} className="h-9" aria-invalid={!!error || undefined} />
        </Field>
        <Button type="submit" size="lg" className="h-9 w-full">
          Send reset link
        </Button>
      </form>
      <button onClick={() => setScreen('login')} className="mt-6 flex w-full items-center justify-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-3.5" /> Back to login
      </button>
    </Shell>
  )
}

function Reset({ setScreen, registered, setRegistered }: { setScreen: (s: AuthScreen) => void; registered: RegisteredStudent | null; setRegistered: (r: RegisteredStudent | null) => void }) {
  const [pw, setPw] = useState('')
  const [confirm, setConfirm] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [done, setDone] = useState(false)
  const strength = passwordStrength(pw)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const er: Record<string, string> = {}
    if (pw.length < 8) er.pw = 'Use at least 8 characters.'
    if (confirm !== pw) er.confirm = 'Passwords do not match.'
    setErrors(er)
    if (Object.keys(er).length) return
    if (registered) setRegistered({ ...registered, password: pw })
    setDone(true)
  }

  if (done) {
    return (
      <Shell>
        <div className="flex flex-col items-center text-center">
          <span className="flex size-14 items-center justify-center rounded-2xl bg-success/10 text-success">
            <CheckCircle2 className="size-7" aria-hidden="true" />
          </span>
          <h1 className="mt-4 text-2xl font-semibold tracking-tight">Password updated</h1>
          <p className="mt-1 text-sm text-muted-foreground">Sign in with your new password.</p>
        </div>
        <Button size="lg" className="mt-6 h-9 w-full" onClick={() => setScreen('login')}>
          Back to login
        </Button>
      </Shell>
    )
  }

  return (
    <Shell>
      <Heading title="Reset password" description="Choose a new password for your InternHub account." />
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <Field label="New password" htmlFor="rs-pw" error={errors.pw}>
          <PasswordInput id="rs-pw" value={pw} onChange={setPw} autoComplete="new-password" invalid={!!errors.pw} />
          {pw && (
            <div className="flex items-center gap-3">
              <Bar value={strength.value} tone={strength.tone} className="h-1.5" />
              <span className="w-16 shrink-0 text-right text-xs text-muted-foreground">{strength.label}</span>
            </div>
          )}
        </Field>
        <Field label="Confirm new password" htmlFor="rs-confirm" error={errors.confirm}>
          <PasswordInput id="rs-confirm" value={confirm} onChange={setConfirm} autoComplete="new-password" invalid={!!errors.confirm} />
        </Field>
        <Button type="submit" size="lg" className="h-9 w-full">
          Update password
        </Button>
      </form>
    </Shell>
  )
}
