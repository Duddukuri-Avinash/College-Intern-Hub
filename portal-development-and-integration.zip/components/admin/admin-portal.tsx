'use client'

import { Activity, ArrowRight, Award, Briefcase, ClipboardCheck, GraduationCap, UserCheck, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Bar, PageHeader, Panel, StatCard } from '@/components/shared'
import type { View } from '@/components/app-shell'
import { linkClass } from '@/components/admin/admin-bits'
import { useAdmin } from '@/components/admin/admin-store'
import { Approvals } from '@/components/admin/admin-approvals'
import { StudentsManagement } from '@/components/admin/admin-students'
import { FacultyManagement } from '@/components/admin/admin-faculty'
import { Departments } from '@/components/admin/admin-departments'
import { RolesPermissions } from '@/components/admin/admin-roles'
import { InternshipControl } from '@/components/admin/admin-internships'
import { Moderation } from '@/components/admin/admin-moderation'
import { Announcements } from '@/components/admin/admin-announcements'
import { Reports } from '@/components/admin/admin-reports'
import { AuditLogs } from '@/components/admin/admin-audit'
import { Settings } from '@/components/admin/admin-settings'
import { branchStats, COLLEGE, skillGaps, verificationQueue } from '@/lib/data'

const titles: Record<string, [string, string]> = {
  overview: ['Platform Overview', `College-wide internship analytics for ${COLLEGE.name}`],
  approvals: ['Approvals', 'New faculty registrations waiting for review'],
  students: ['Manage Students', 'Profiles, eligibility, and internship records'],
  faculty: ['Manage Faculty', 'Coordinators and verification permissions'],
  departments: ['Departments & Academic Setup', 'Branches, sections, academic years, and eligibility defaults'],
  roles: ['Roles & Permissions', 'Control what each role can do across the platform'],
  internships: ['Manage Internships', 'All listings across sources'],
  moderation: ['Moderation', 'Reported posts and experience reviews'],
  announcements: ['Announcements', 'Broadcast messages to students and faculty'],
  reports: ['Reports & Exports', 'Participation, verification, and skill-gap reports'],
  audit: ['Audit Logs', 'Every verification and admin action, timestamped'],
  settings: ['Settings', 'Platform configuration'],
}

export function AdminPortal({ section, navigate }: { section: string; navigate: (v: View) => void }) {
  const [title, desc] = titles[section] ?? titles.overview
  const go = (s: string) => navigate({ name: 'admin', section: s })
  return (
    <>
      <PageHeader title={title} description={desc} />
      {section === 'overview' && <Overview go={go} />}
      {section === 'approvals' && <Approvals />}
      {section === 'students' && <StudentsManagement />}
      {section === 'faculty' && <FacultyManagement />}
      {section === 'departments' && <Departments />}
      {section === 'roles' && <RolesPermissions />}
      {section === 'internships' && <InternshipControl />}
      {section === 'moderation' && <Moderation />}
      {section === 'announcements' && <Announcements />}
      {section === 'reports' && <Reports />}
      {section === 'audit' && <AuditLogs />}
      {section === 'settings' && <Settings />}
    </>
  )
}

function Overview({ go }: { go: (s: string) => void }) {
  const { approvals, faculty, audit } = useAdmin()
  const total = branchStats.reduce((n, b) => n + b.students, 0)
  const interning = branchStats.reduce((n, b) => n + b.interning, 0)
  const pending = approvals.filter((a) => a.status === 'Pending').length
  const link = (s: string, label: string) => ({ className: linkClass, onClick: () => go(s), 'aria-label': label })
  return (
    <>
      {pending > 0 && (
        <div className="flex flex-col gap-3 rounded-xl border border-primary/20 bg-accent p-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="flex items-center gap-2 text-sm text-accent-foreground"><UserCheck className="size-4 text-primary" aria-hidden="true" /> {pending} faculty registration{pending > 1 ? 's are' : ' is'} waiting for approval.</p>
          <Button size="sm" onClick={() => go('approvals')}>Review <ArrowRight /></Button>
        </div>
      )}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <button type="button" {...link('students', 'Open Manage Students')}><StatCard label="Total Students" value={total.toLocaleString('en-IN')} hint="Across 9 branches" icon={<GraduationCap className="size-4" />} /></button>
        <button type="button" {...link('faculty', 'Open Manage Faculty')}><StatCard label="Faculty Coordinators" value={42 + faculty.length - 7} hint="All departments" icon={<Users className="size-4" />} /></button>
        <button type="button" {...link('reports', 'Open Reports')}><StatCard label="Internships (2025–26)" value={interning.toLocaleString('en-IN')} hint={`${Math.round((interning / total) * 100)}% participation`} icon={<Briefcase className="size-4" />} /></button>
        <button type="button" {...link('audit', 'Open Audit Logs')}><StatCard label="Verifications this week" value={128} hint={`${verificationQueue.length} pending now`} icon={<ClipboardCheck className="size-4" />} /></button>
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Student participation by branch" action={<Button variant="ghost" size="sm" onClick={() => go('reports')}>Reports <ArrowRight /></Button>}>
          <ul className="flex flex-col gap-3">
            {branchStats.map((b) => {
              const pct = Math.round((b.interning / b.students) * 100)
              return (
                <li key={b.branch} className="grid grid-cols-[56px_1fr_80px] items-center gap-3 text-sm">
                  <span className="font-medium">{b.branch}</span>
                  <Bar value={pct} tone={pct > 50 ? 'success' : 'primary'} />
                  <span className="text-right text-xs tabular-nums text-muted-foreground">{b.interning}/{b.students}</span>
                </li>
              )
            })}
          </ul>
        </Panel>
        <Panel title="Skill-gap insights">
          <p className="mb-4 text-xs text-muted-foreground">Share of listings requiring a skill vs. share of students who have it.</p>
          <ul className="flex flex-col gap-4">
            {skillGaps.map((s) => (
              <li key={s.skill}>
                <div className="mb-1.5 flex justify-between text-sm"><span className="font-medium">{s.skill}</span><span className="text-xs text-destructive">Gap {s.demand - s.supply}%</span></div>
                <div className="flex flex-col gap-1">
                  <Bar value={s.demand} />
                  <Bar value={s.supply} tone="success" />
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5"><span className="size-2 rounded-full bg-primary" /> Industry demand</span>
            <span className="flex items-center gap-1.5"><span className="size-2 rounded-full bg-success" /> Student supply</span>
          </div>
        </Panel>
      </div>
      <div className="grid gap-6 lg:grid-cols-3">
        <Panel title="Verification activity" className="lg:col-span-2">
          <div className="flex h-40 items-end gap-2" aria-label="Verifications per day this week">
            {[18, 24, 15, 31, 22, 12, 6].map((v, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-1.5">
                <span className="text-xs tabular-nums text-muted-foreground">{v}</span>
                <div className="w-full rounded-t-md bg-primary/80" style={{ height: `${(v / 31) * 100}%` }} />
                <span className="text-[11px] text-muted-foreground">{['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Recent activity" action={<Button variant="ghost" size="sm" onClick={() => go('audit')}>All <ArrowRight /></Button>}>
          <ul className="flex flex-col gap-3">
            {audit.slice(0, 4).map((l) => (
              <li key={l.id} className="flex gap-2.5">
                <Activity className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                <div><p className="text-sm font-medium">{l.action}</p><p className="text-xs text-muted-foreground">{l.actor} · {l.target}</p></div>
              </li>
            ))}
          </ul>
          <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground"><Award className="size-3.5" /> 412 certificates verified this year</p>
        </Panel>
      </div>
    </>
  )
}
