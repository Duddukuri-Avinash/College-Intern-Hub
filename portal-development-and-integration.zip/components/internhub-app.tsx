'use client'

import { useState } from 'react'
import { toast } from 'sonner'
import { AppShell, type Role, type View } from '@/components/app-shell'
import { AuthFlow, type AuthScreen, type RegisteredStudent } from '@/components/auth/auth-flow'
import { StudentDashboard } from '@/components/student/dashboard'
import { Discover } from '@/components/student/discover'
import { InternshipDetail } from '@/components/student/internship-detail'
import { Tracker } from '@/components/student/tracker'
import { MyInternships } from '@/components/student/my-internships'
import { Seniors, ExperienceDetail, ShareExperience } from '@/components/student/seniors'
import { StudentProfile } from '@/components/student/profile'
import { Onboarding } from '@/components/student/onboarding'
import { ResumeAnalysis } from '@/components/student/resume-analysis'
import { SkillRoadmap } from '@/components/student/roadmap'
import { SubmitInternship } from '@/components/student/submit-internship'
import { StudentSettings } from '@/components/student/settings'
import { FacultyDashboard } from '@/components/faculty/dashboard'
import { VerificationCenter } from '@/components/faculty/verification'
import { PostOpportunity } from '@/components/faculty/post-opportunity'
import { AdminPortal } from '@/components/admin/admin-portal'
import { FacultyStoreProvider } from '@/components/faculty/faculty-store'
import { AdminStoreProvider } from '@/components/admin/admin-store'
import { ManageOpportunities } from '@/components/faculty/manage-opportunities'
import { FacultyStudents, FacultyStudentDetail } from '@/components/faculty/students'
import { FacultyRequests } from '@/components/faculty/requests'
import { FacultyReports } from '@/components/faculty/reports'
import { FacultyAnnouncements } from '@/components/faculty/announcements'
import { FacultySettings } from '@/components/faculty/settings'

const home: Record<Role, View> = {
  student: { name: 'student-dashboard' },
  faculty: { name: 'faculty-dashboard' },
  admin: { name: 'admin', section: 'overview' },
}

export function InternHubApp() {
  const [role, setRole] = useState<Role>('student')
  const [view, setView] = useState<View>(home.student)
  // Students start on the login screen. Set to null to open straight on the dashboard.
  const [auth, setAuth] = useState<AuthScreen | null>('login')
  const [registered, setRegistered] = useState<RegisteredStudent | null>(null)
  const [firstLogin, setFirstLogin] = useState(false)

  const navigate = (v: View) => {
    setView(v)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  if (auth) {
    return (
      <AuthFlow
        screen={auth}
        setScreen={setAuth}
        registered={registered}
        setRegistered={setRegistered}
        onLoggedIn={({ firstLogin: first }) => {
          setFirstLogin(first)
          setRole('student')
          setView(first ? { name: 'onboarding' } : home.student)
          setAuth(null)
        }}
        onFacultyLoggedIn={() => {
          setRole('faculty')
          setView(home.faculty)
          setAuth(null)
        }}
        onAdminLoggedIn={() => {
          setRole('admin')
          setView(home.admin)
          setAuth(null)
        }}
        onDemo={() => {
          setFirstLogin(false)
          setRole('student')
          setView(home.student)
          setAuth(null)
        }}
      />
    )
  }

  return (
    <FacultyStoreProvider>
    <AdminStoreProvider>
    <AppShell
      role={role}
      onRoleChange={(r) => {
        setRole(r)
        navigate(home[r])
      }}
      view={view}
      onNavigate={navigate}
      onLogout={() => {
        setAuth('login')
        toast.info('You have been logged out')
      }}
    >
      {view.name === 'student-dashboard' && <StudentDashboard navigate={navigate} />}
      {view.name === 'discover' && <Discover navigate={navigate} />}
      {view.name === 'internship' && <InternshipDetail id={view.id} navigate={navigate} />}
      {view.name === 'tracker' && <Tracker navigate={navigate} />}
      {view.name === 'my-internships' && <MyInternships />}
      {view.name === 'seniors' && <Seniors navigate={navigate} />}
      {view.name === 'experience' && <ExperienceDetail id={view.id} navigate={navigate} />}
      {view.name === 'share-experience' && <ShareExperience navigate={navigate} />}
      {view.name === 'profile' && <StudentProfile navigate={navigate} />}
      {view.name === 'onboarding' && <Onboarding navigate={(v) => { setFirstLogin(false); navigate(v) }} firstLogin={firstLogin} name={registered?.name} />}
      {view.name === 'resume-analysis' && <ResumeAnalysis navigate={navigate} />}
      {view.name === 'roadmap' && <SkillRoadmap navigate={navigate} />}
      {view.name === 'submit-internship' && <SubmitInternship navigate={navigate} />}
      {view.name === 'settings' && <StudentSettings />}
      {view.name === 'faculty-dashboard' && <FacultyDashboard navigate={navigate} />}
      {view.name === 'verification' && <VerificationCenter />}
      {view.name === 'post-opportunity' && <PostOpportunity key={view.editId ?? 'new'} editId={view.editId} navigate={navigate} />}
      {view.name === 'faculty-opportunities' && <ManageOpportunities navigate={navigate} />}
      {view.name === 'faculty-students' && <FacultyStudents key={view.quick ?? 'all'} quick={view.quick} navigate={navigate} />}
      {view.name === 'faculty-student' && <FacultyStudentDetail id={view.id} navigate={navigate} />}
      {view.name === 'faculty-requests' && <FacultyRequests />}
      {view.name === 'faculty-reports' && <FacultyReports />}
      {view.name === 'faculty-announcements' && <FacultyAnnouncements />}
      {view.name === 'faculty-settings' && <FacultySettings />}
      {view.name === 'admin' && <AdminPortal section={view.section} navigate={navigate} />}
    </AppShell>
    </AdminStoreProvider>
    </FacultyStoreProvider>
  )
}
