import { InternHubApp } from '@/components/internhub-app'

export default function Page() {
  return <InternHubApp />
}
