export const COLLEGE = {
  name: 'R.V.R & J.C College of Engineering',
  short: 'RVR&JC',
  location: 'Chowdavaram, Guntur, Andhra Pradesh',
}

export type Source = 'College Opportunity' | 'Self-Found' | 'Senior Referral'
export type Mode = 'Remote' | 'On-site' | 'Hybrid'

export type Internship = {
  id: string
  company: string
  role: string
  skills: string[]
  duration: string
  mode: Mode
  location: string
  stipend: number
  deadline: string
  source: Source
  branches: string[]
  years: number[]
  minCgpa: number
  match: number
  description: string
  matchReasons: string[]
  missingSkills: string[]
  link: string
}

export const internships: Internship[] = [
  {
    id: 'i1',
    company: 'Infosys',
    role: 'Software Engineering Intern',
    skills: ['Java', 'Spring Boot', 'SQL'],
    duration: '8 weeks',
    mode: 'Hybrid',
    location: 'Hyderabad',
    stipend: 15000,
    deadline: '2026-10-18',
    source: 'College Opportunity',
    branches: ['CSE', 'IT', 'CSBS'],
    years: [3, 4],
    minCgpa: 7.0,
    match: 92,
    description:
      'Work with the Finacle platform team building backend microservices. You will write production Java, participate in code reviews, and ship a feature end-to-end with mentorship from senior engineers.',
    matchReasons: ['Java and SQL listed on your profile', 'CSE, 3rd year — eligible', 'CGPA 8.4 exceeds 7.0 cut-off'],
    missingSkills: ['Spring Boot'],
    link: 'https://www.infosys.com/careers',
  },
  {
    id: 'i2',
    company: 'Zoho Corporation',
    role: 'Frontend Developer Intern',
    skills: ['React', 'JavaScript', 'CSS'],
    duration: '12 weeks',
    mode: 'On-site',
    location: 'Chennai',
    stipend: 20000,
    deadline: '2026-10-12',
    source: 'Senior Referral',
    branches: ['CSE', 'IT', 'ECE'],
    years: [3, 4],
    minCgpa: 6.5,
    match: 88,
    description:
      'Build UI components for Zoho CRM used by millions. Referred by Sai Kiran (CSE 2025), who interned on the same team last summer.',
    matchReasons: ['React project in your portfolio', 'Referral from a verified senior', 'Eligible branch and year'],
    missingSkills: [],
    link: 'https://careers.zohocorp.com',
  },
  {
    id: 'i3',
    company: 'ISRO – SDSC SHAR',
    role: 'Embedded Systems Trainee',
    skills: ['C', 'Embedded C', 'Microcontrollers'],
    duration: '6 weeks',
    mode: 'On-site',
    location: 'Sriharikota',
    stipend: 0,
    deadline: '2026-10-25',
    source: 'College Opportunity',
    branches: ['ECE', 'EEE'],
    years: [3],
    minCgpa: 7.5,
    match: 54,
    description:
      'Summer training program at the Satish Dhawan Space Centre covering telemetry systems and embedded firmware for launch vehicle instrumentation.',
    matchReasons: ['C programming on your profile'],
    missingSkills: ['Embedded C', 'Microcontrollers'],
    link: 'https://www.shar.gov.in',
  },
  {
    id: 'i4',
    company: 'Tata Consultancy Services',
    role: 'Data Analyst Intern',
    skills: ['Python', 'Pandas', 'Power BI'],
    duration: '10 weeks',
    mode: 'Remote',
    location: 'Remote',
    stipend: 12000,
    deadline: '2026-10-30',
    source: 'College Opportunity',
    branches: ['CSE', 'IT', 'CSBS', 'AI&ML'],
    years: [2, 3, 4],
    minCgpa: 6.0,
    match: 81,
    description:
      'Analyse operational datasets for a banking client and build dashboards that summarise KPIs for leadership reviews.',
    matchReasons: ['Python and Pandas on your profile', 'Remote — no relocation needed'],
    missingSkills: ['Power BI'],
    link: 'https://www.tcs.com/careers',
  },
  {
    id: 'i5',
    company: 'Swiggy',
    role: 'Machine Learning Intern',
    skills: ['Python', 'Machine Learning', 'TensorFlow'],
    duration: '16 weeks',
    mode: 'Hybrid',
    location: 'Bengaluru',
    stipend: 35000,
    deadline: '2026-11-05',
    source: 'Self-Found',
    branches: ['CSE', 'AI&ML'],
    years: [4],
    minCgpa: 8.0,
    match: 73,
    description:
      'Join the delivery-time prediction team to experiment with gradient boosted models and deep learning features on real order data.',
    matchReasons: ['Python and ML coursework', 'CGPA 8.4 exceeds 8.0 cut-off'],
    missingSkills: ['TensorFlow'],
    link: 'https://careers.swiggy.com',
  },
  {
    id: 'i6',
    company: 'L&T Construction',
    role: 'Site Engineering Intern',
    skills: ['AutoCAD', 'Surveying', 'STAAD Pro'],
    duration: '8 weeks',
    mode: 'On-site',
    location: 'Vijayawada',
    stipend: 10000,
    deadline: '2026-10-20',
    source: 'College Opportunity',
    branches: ['Civil'],
    years: [3, 4],
    minCgpa: 6.5,
    match: 22,
    description: 'Hands-on site exposure on the Amaravati infrastructure project including quality checks and progress reporting.',
    matchReasons: [],
    missingSkills: ['AutoCAD', 'Surveying', 'STAAD Pro'],
    link: 'https://www.larsentoubro.com/careers',
  },
]

export type AppStatus = 'Saved' | 'Applied' | 'Interview' | 'Selected' | 'Rejected' | 'Withdrawn'

export const applications: { id: string; internshipId: string; status: AppStatus; updated: string; note: string }[] = [
  { id: 'a1', internshipId: 'i1', status: 'Interview', updated: '2026-10-05', note: 'Technical round on Oct 10, 11:00 AM' },
  { id: 'a2', internshipId: 'i2', status: 'Applied', updated: '2026-10-03', note: 'Referral submitted by Sai Kiran' },
  { id: 'a3', internshipId: 'i4', status: 'Saved', updated: '2026-10-06', note: 'Complete Power BI course first' },
  { id: 'a4', internshipId: 'i5', status: 'Selected', updated: '2026-09-28', note: 'Offer letter received' },
  { id: 'a5', internshipId: 'i3', status: 'Rejected', updated: '2026-09-20', note: 'Not shortlisted' },
  { id: 'a6', internshipId: 'i6', status: 'Withdrawn', updated: '2026-09-15', note: 'Branch mismatch' },
]

export type VerifyStatus = 'Pending' | 'Verified' | 'Rejected' | 'Additional Proof Required'

export const lifecycleStages = [
  'Offer Received',
  'Offer Uploaded',
  'Verified',
  'In Progress',
  'Completed',
  'Certificate Verified',
] as const

export const myInternships = [
  {
    id: 'm1',
    company: 'Swiggy',
    role: 'Machine Learning Intern',
    period: 'Nov 2026 – Feb 2027',
    stage: 1,
    offerStatus: 'Additional Proof Required' as VerifyStatus,
    certificateStatus: null as VerifyStatus | null,
    facultyNote:
      'Offer letter does not show the stipend amount or reporting manager. Please upload the HR confirmation email or a signed offer copy.',
    mentor: 'Dr. K. Srinivasa Rao',
  },
  {
    id: 'm2',
    company: 'Cognizant',
    role: 'Web Development Intern',
    period: 'May 2026 – Jul 2026',
    stage: 5,
    offerStatus: 'Verified' as VerifyStatus,
    certificateStatus: 'Verified' as VerifyStatus,
    facultyNote: '',
    mentor: 'Dr. P. Lakshmi',
  },
]

export const experiences = [
  {
    id: 'e1',
    name: 'Sai Kiran M.',
    batch: 'CSE 2025',
    company: 'Zoho Corporation',
    role: 'Frontend Developer Intern',
    duration: '12 weeks',
    skills: ['React', 'TypeScript', 'Redux'],
    obtained: 'Senior Referral',
    project: 'Rebuilt the Zoho CRM deal pipeline board with drag-and-drop and offline support.',
    learned: 'Writing maintainable component APIs and performance profiling in large React apps.',
    interview:
      'One online coding test (3 DSA problems, 90 mins), followed by a JavaScript deep-dive round and a short HR conversation.',
    challenges: 'Adapting to a large legacy codebase and Zoho’s internal UI framework in the first two weeks.',
    tech: ['React', 'TypeScript', 'Redux', 'Jest', 'Webpack'],
    recommendation: 'Be strong in JavaScript closures, event loop, and DOM APIs. Build at least one complex UI project.',
    rating: 4.8,
  },
  {
    id: 'e2',
    name: 'Harika P.',
    batch: 'IT 2025',
    company: 'Infosys',
    role: 'Software Engineering Intern',
    duration: '8 weeks',
    skills: ['Java', 'Spring Boot', 'MySQL'],
    obtained: 'College Opportunity',
    project: 'Built a REST service for loan eligibility checks on Finacle with automated tests.',
    learned: 'Enterprise Java patterns, CI pipelines, and writing clear technical documentation.',
    interview: 'Aptitude + coding test via HackerRank, then one technical interview focused on OOP and SQL joins.',
    challenges: 'Understanding banking domain terminology and strict code review standards.',
    tech: ['Java', 'Spring Boot', 'MySQL', 'Jenkins'],
    recommendation: 'Revise OOP concepts and practise SQL queries. Infosys Springboard courses help a lot.',
    rating: 4.5,
  },
  {
    id: 'e3',
    name: 'Venkatesh R.',
    batch: 'ECE 2024',
    company: 'Texas Instruments',
    role: 'Analog Design Intern',
    duration: '24 weeks',
    skills: ['Cadence', 'Analog Circuits', 'MATLAB'],
    obtained: 'Self-Found',
    project: 'Characterised a low-dropout regulator across temperature corners.',
    learned: 'Real silicon validation flows and how to communicate results to design leads.',
    interview: 'Two technical rounds on op-amps, MOSFET biasing, and a circuit analysis problem.',
    challenges: 'Long simulation cycles; learned to plan experiments carefully.',
    tech: ['Cadence Virtuoso', 'MATLAB', 'LabVIEW'],
    recommendation: 'Master Razavi’s fundamentals. Apply early through TI WiSH and campus programs.',
    rating: 4.9,
  },
]

export const notifications = [
  { id: 'n1', title: 'Offer letter needs additional proof', body: 'Dr. K. Srinivasa Rao requested more info on your Swiggy offer.', time: '2h ago', type: 'warning' },
  { id: 'n2', title: 'New college opportunity', body: 'TCS Data Analyst Intern matches 81% of your profile.', time: '5h ago', type: 'info' },
  { id: 'n3', title: 'Interview scheduled', body: 'Infosys technical round on Oct 10, 11:00 AM.', time: '1d ago', type: 'info' },
  { id: 'n4', title: 'Certificate verified', body: 'Your Cognizant internship certificate has been verified.', time: '3d ago', type: 'success' },
]

export const student = {
  name: 'Ananya Reddy',
  initials: 'AR',
  regNo: 'Y23CS042',
  branch: 'CSE',
  year: 3,
  cgpa: 8.4,
  profileCompletion: 78,
  readiness: 72,
  semester: 5,
  section: 'A',
  batch: '2023 – 2027',
  degree: 'B.Tech, Computer Science & Engineering',
  email: 'ananya.reddy@rvrjc.ac.in',
  phone: '+91 98485 21436',
  dob: '2005-03-14',
  gender: 'Female',
  address: 'Brodipet, Guntur, Andhra Pradesh – 522002',
  mentor: 'Dr. K. Srinivasa Rao',
  linkedin: 'linkedin.com/in/ananya-reddy',
  github: 'github.com/ananyareddy',
  resume: 'Ananya_Reddy_Resume.pdf',
  resumeUpdated: '2026-09-22',
  about:
    'Third-year CSE student interested in full-stack development and applied machine learning. Enjoy building products that solve campus problems.',
  skills: [
    { name: 'Java', level: 85 },
    { name: 'Python', level: 80 },
    { name: 'SQL', level: 75 },
    { name: 'React', level: 70 },
    { name: 'JavaScript', level: 72 },
    { name: 'Pandas', level: 65 },
    { name: 'Machine Learning', level: 55 },
    { name: 'C', level: 68 },
  ],
  semesters: [
    { sem: 1, sgpa: 8.1 },
    { sem: 2, sgpa: 8.3 },
    { sem: 3, sgpa: 8.5 },
    { sem: 4, sgpa: 8.6 },
  ],
  education: [
    { level: 'B.Tech (CSE)', institution: 'R.V.R & J.C College of Engineering', period: '2023 – 2027', score: 'CGPA 8.4 (till Sem 4)' },
    { level: 'Intermediate (MPC)', institution: 'Sri Chaitanya Junior College, Guntur', period: '2021 – 2023', score: '96.4%' },
    { level: 'SSC', institution: 'Bhashyam High School, Guntur', period: '2021', score: 'GPA 10.0' },
  ],
  projects: [
    { title: 'Campus Canteen Pre-order App', tech: ['React', 'Node.js', 'MongoDB'], summary: 'Order-ahead web app used by 300+ students to skip canteen queues.' },
    { title: 'Attendance Anomaly Detector', tech: ['Python', 'Pandas', 'scikit-learn'], summary: 'Flags irregular attendance patterns from department records for mentors.' },
  ],
  certifications: [
    { name: 'Oracle Certified Associate – Java SE', issuer: 'Oracle', year: '2025' },
    { name: 'Python for Data Science', issuer: 'NPTEL (IIT Madras)', year: '2025' },
    { name: 'AWS Cloud Practitioner Essentials', issuer: 'AWS Skill Builder', year: '2026' },
  ],
  achievements: [
    'Finalist, Smart India Hackathon 2025 (internal round)',
    'Merit scholarship – top 5% of CSE batch, 2024',
    'Core member, CSI Student Chapter',
  ],
}

export const faculty = {
  name: 'Dr. K. Srinivasa Rao',
  initials: 'KS',
  dept: 'Department of CSE',
  designation: 'Internship Coordinator',
}

export const verificationQueue = [
  { id: 'v1', type: 'Offer Letter', student: 'Ananya Reddy', regNo: 'Y23CS042', branch: 'CSE', company: 'Swiggy', role: 'ML Intern', submitted: '2026-10-06', status: 'Pending' as VerifyStatus, file: 'swiggy_offer_letter.pdf' },
  { id: 'v2', type: 'Certificate', student: 'Rahul Varma', regNo: 'Y22IT017', branch: 'IT', company: 'Wipro', role: 'Cloud Intern', submitted: '2026-10-05', status: 'Pending' as VerifyStatus, file: 'wipro_certificate.pdf' },
  { id: 'v3', type: 'Self-Found', student: 'Divya Sri K.', regNo: 'Y23CS110', branch: 'CSE', company: 'Razorpay', role: 'Backend Intern', submitted: '2026-10-05', status: 'Pending' as VerifyStatus, file: 'razorpay_offer.pdf' },
  { id: 'v4', type: 'Experience', student: 'Harika P.', regNo: 'Y21IT033', branch: 'IT', company: 'Infosys', role: 'SE Intern', submitted: '2026-10-04', status: 'Pending' as VerifyStatus, file: 'experience_writeup' },
  { id: 'v5', type: 'Offer Letter', student: 'Mohan Teja', regNo: 'Y23EC021', branch: 'ECE', company: 'Qualcomm', role: 'VLSI Intern', submitted: '2026-10-03', status: 'Additional Proof Required' as VerifyStatus, file: 'qualcomm_offer.pdf' },
  { id: 'v6', type: 'Certificate', student: 'Sneha L.', regNo: 'Y22CS088', branch: 'CSE', company: 'Accenture', role: 'Analyst Intern', submitted: '2026-10-02', status: 'Pending' as VerifyStatus, file: 'accenture_cert.pdf' },
]

export const branches = ['CSE', 'IT', 'ECE', 'EEE', 'Mechanical', 'Civil', 'Chemical', 'CSBS', 'AI&ML']

export const branchStats = [
  { branch: 'CSE', students: 720, interning: 412 },
  { branch: 'IT', students: 360, interning: 198 },
  { branch: 'ECE', students: 480, interning: 205 },
  { branch: 'EEE', students: 240, interning: 74 },
  { branch: 'Mech', students: 240, interning: 61 },
  { branch: 'Civil', students: 180, interning: 48 },
  { branch: 'AI&ML', students: 180, interning: 96 },
]

export const skillGaps = [
  { skill: 'Cloud (AWS/Azure)', demand: 84, supply: 31 },
  { skill: 'React / Frontend', demand: 76, supply: 52 },
  { skill: 'Data Analytics', demand: 71, supply: 44 },
  { skill: 'Embedded Systems', demand: 58, supply: 27 },
  { skill: 'DevOps', demand: 52, supply: 18 },
]

export const auditLogs = [
  { id: 'l1', actor: 'Dr. K. Srinivasa Rao', action: 'Verified offer letter', target: 'Y23CS077 · Amazon', time: '2026-10-07 09:42' },
  { id: 'l2', actor: 'Dr. P. Lakshmi', action: 'Posted college opportunity', target: 'TCS Data Analyst Intern', time: '2026-10-07 08:15' },
  { id: 'l3', actor: 'Admin · M. Ravi', action: 'Updated platform settings', target: 'Verification SLA → 3 days', time: '2026-10-06 17:20' },
  { id: 'l4', actor: 'Dr. S. Bhaskar', action: 'Rejected certificate', target: 'Y22ME014 · Unverifiable issuer', time: '2026-10-06 14:03' },
  { id: 'l5', actor: 'Admin · M. Ravi', action: 'Suspended experience post', target: 'Reported for promotional content', time: '2026-10-06 11:48' },
]

export function daysUntil(date: string) {
  const today = new Date('2026-10-07')
  return Math.ceil((new Date(date).getTime() - today.getTime()) / 86400000)
}

export function formatDate(date: string) {
  return new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
}
