import { auditLogs, internships, type VerifyStatus } from '@/lib/data'

export const ADMIN_TODAY = '2026-10-08'
export const COLLEGE_DOMAIN = '@rvrjc.ac.in'

export const BRANCHES = ['CSE', 'IT', 'ECE', 'EEE', 'Mech', 'Civil', 'AI&ML'] as const
export const SECTIONS = ['A', 'B', 'C'] as const
export const YEARS = [1, 2, 3, 4] as const

/* ------------------------------ Students ------------------------------ */

export type StudentStatus = 'Active' | 'Inactive'
export type InternshipState = 'Interning' | 'Completed' | 'Applied' | 'None'

export type AdminStudent = {
  id: string
  name: string
  roll: string
  branch: string
  year: number
  section: string
  email: string
  phone: string
  cgpa: number
  status: StudentStatus
  internship: InternshipState
  internships: number
  profile: number
  resume: number
  docs: { name: string; status: VerifyStatus }[]
  activity: { time: string; text: string }[]
}

const firstNames = ['Ananya', 'Rahul', 'Divya', 'Mohan', 'Sneha', 'Karthik', 'Lakshmi', 'Sai', 'Harika', 'Vamsi', 'Pavani', 'Teja', 'Keerthi', 'Nikhil', 'Bhavana', 'Rohith', 'Sravya', 'Manoj', 'Deepika', 'Akhil', 'Yamini', 'Charan', 'Meghana', 'Praneeth', 'Swathi', 'Gopi', 'Hema', 'Rakesh', 'Tejaswini', 'Siddharth', 'Nandini', 'Varun', 'Pooja', 'Kiran', 'Ramya', 'Abhinav']
const lastNames = ['Reddy', 'Varma', 'Sri K.', 'Teja', 'L.', 'Chowdary', 'Prasanna', 'Kiran M.', 'Naidu', 'Krishna', 'Rao', 'Babu', 'Sai P.', 'Kumar', 'Devi', 'Raju']
const branchCode: Record<string, string> = { CSE: 'CS', IT: 'IT', ECE: 'EC', EEE: 'EE', Mech: 'ME', Civil: 'CE', 'AI&ML': 'AI' }
const states: InternshipState[] = ['Interning', 'Completed', 'Applied', 'None']

export function rollFor(branch: string, year: number, n: number) {
  const batch = 27 - year
  return `Y${batch}${branchCode[branch] ?? 'XX'}${String(n).padStart(3, '0')}`
}

export const studentsSeed: AdminStudent[] = firstNames.map((first, i) => {
  const branch = BRANCHES[i % 5 === 4 ? (i % 7) : i % 3 === 0 ? 0 : i % 7]
  const year = (i % 4) + 1
  const section = SECTIONS[i % 3]
  const roll = rollFor(branch, year, 10 + ((i * 37) % 180))
  const internship = year === 1 ? 'None' : states[(i * 3) % 4]
  const count = internship === 'None' ? 0 : internship === 'Applied' ? 0 : 1 + (i % 3)
  const name = `${first} ${lastNames[i % lastNames.length]}`
  return {
    id: `s${i + 1}`,
    name,
    roll,
    branch,
    year,
    section,
    email: `${first.toLowerCase()}.${roll.toLowerCase()}${COLLEGE_DOMAIN}`,
    phone: `9${String(840000000 + i * 271_483).slice(0, 4)} ${String(10000 + i * 791).slice(0, 5)}`,
    cgpa: Math.round((6.8 + ((i * 17) % 30) / 10) * 10) / 10,
    status: i % 11 === 7 ? 'Inactive' : 'Active',
    internship,
    internships: count,
    profile: 55 + ((i * 13) % 45),
    resume: 40 + ((i * 19) % 58),
    docs:
      count === 0
        ? []
        : [
            { name: 'Offer letter', status: 'Verified' },
            { name: 'Internship certificate', status: internship === 'Completed' ? 'Verified' : 'Pending' },
            ...(i % 5 === 0 ? [{ name: 'Weekly report', status: 'Additional Proof Required' as VerifyStatus }] : []),
          ],
    activity: [
      { time: '2026-10-07 10:12', text: 'Updated skills on profile' },
      { time: '2026-10-05 16:40', text: internship === 'None' ? 'Viewed 4 internship listings' : 'Uploaded offer letter for verification' },
      { time: '2026-09-29 09:05', text: 'Ran AI resume analysis' },
    ],
  }
})

/* ------------------------------ Faculty ------------------------------ */

export type FacultyRole = 'Internship Coordinator' | 'Faculty Mentor' | 'Reviewer'
export const FACULTY_ROLES: FacultyRole[] = ['Internship Coordinator', 'Faculty Mentor', 'Reviewer']

export type AdminFaculty = {
  id: string
  name: string
  empId: string
  dept: string
  designation: string
  email: string
  roles: FacultyRole[]
  groups: string[]
  status: StudentStatus
  verified: number
  turnaround: number
  pending: { verifications: number; requests: number; reviews: number }
}

export const facultySeed: AdminFaculty[] = [
  { id: 'f1', name: 'Dr. K. Srinivasa Rao', empId: 'RVR1043', dept: 'CSE', designation: 'Professor', email: 'ksrao@rvrjc.ac.in', roles: ['Internship Coordinator'], groups: ['CSE · Year 3 · A', 'CSE · Year 3 · B', 'CSE · Year 4 · A'], status: 'Active', verified: 48, turnaround: 1.6, pending: { verifications: 9, requests: 3, reviews: 1 } },
  { id: 'f2', name: 'Dr. P. Lakshmi', empId: 'RVR1088', dept: 'IT', designation: 'Associate Professor', email: 'plakshmi@rvrjc.ac.in', roles: ['Internship Coordinator', 'Reviewer'], groups: ['IT · Year 3 · A', 'IT · Year 4 · A'], status: 'Active', verified: 31, turnaround: 2.1, pending: { verifications: 6, requests: 2, reviews: 2 } },
  { id: 'f3', name: 'Dr. S. Bhaskar', empId: 'RVR1112', dept: 'Mech', designation: 'Assistant Professor', email: 'sbhaskar@rvrjc.ac.in', roles: ['Faculty Mentor'], groups: ['Mech · Year 3 · A'], status: 'Active', verified: 9, turnaround: 2.8, pending: { verifications: 4, requests: 1, reviews: 0 } },
  { id: 'f4', name: 'Dr. N. Venkata Ramana', empId: 'RVR1027', dept: 'ECE', designation: 'Professor', email: 'nvramana@rvrjc.ac.in', roles: ['Internship Coordinator'], groups: ['ECE · Year 3 · A', 'ECE · Year 4 · B'], status: 'Active', verified: 27, turnaround: 1.9, pending: { verifications: 5, requests: 0, reviews: 1 } },
  { id: 'f5', name: 'Mrs. G. Sravani', empId: 'RVR1204', dept: 'CSE', designation: 'Assistant Professor', email: 'gsravani@rvrjc.ac.in', roles: ['Faculty Mentor', 'Reviewer'], groups: ['CSE · Year 2 · A'], status: 'Active', verified: 14, turnaround: 2.4, pending: { verifications: 3, requests: 2, reviews: 3 } },
  { id: 'f6', name: 'Mr. T. Ravi Teja', empId: 'RVR1219', dept: 'AI&ML', designation: 'Assistant Professor', email: 'travi@rvrjc.ac.in', roles: ['Faculty Mentor'], groups: ['AI&ML · Year 3 · A'], status: 'Active', verified: 11, turnaround: 3.2, pending: { verifications: 7, requests: 1, reviews: 0 } },
  { id: 'f7', name: 'Dr. M. Padmaja', empId: 'RVR1056', dept: 'EEE', designation: 'Head of Department', email: 'mpadmaja@rvrjc.ac.in', roles: ['Reviewer'], groups: ['EEE · Year 4 · A'], status: 'Inactive', verified: 0, turnaround: 0, pending: { verifications: 2, requests: 1, reviews: 0 } },
]

/* ------------------------------ Approvals ------------------------------ */

export type ApprovalStatus = 'Pending' | 'Approved' | 'Rejected' | 'Correction requested'

export type FacultyApproval = {
  id: string
  name: string
  empId: string
  dept: string
  designation: string
  email: string
  date: string
  status: ApprovalStatus
  note?: string
}

export const approvalsSeed: FacultyApproval[] = [
  { id: 'a1', name: 'Dr. R. Hari Prasad', empId: 'RVR1231', dept: 'CSE', designation: 'Assistant Professor', email: 'rhprasad@rvrjc.ac.in', date: '2026-10-07', status: 'Pending' },
  { id: 'a2', name: 'Mrs. K. Anitha', empId: 'RVR1236', dept: 'IT', designation: 'Assistant Professor', email: 'kanitha@rvrjc.ac.in', date: '2026-10-07', status: 'Pending' },
  { id: 'a3', name: 'Dr. B. Suresh Babu', empId: 'RVR1102', dept: 'Civil', designation: 'Associate Professor', email: 'bsuresh@rvrjc.ac.in', date: '2026-10-06', status: 'Pending' },
  { id: 'a4', name: 'Mr. P. Naveen', empId: 'RVR1240', dept: 'AI&ML', designation: 'Assistant Professor', email: 'pnaveen.ai@gmail.com', date: '2026-10-05', status: 'Pending' },
  { id: 'a5', name: 'Dr. V. Usha Rani', empId: 'RVR1075', dept: 'ECE', designation: 'Professor', email: 'vusharani@rvrjc.ac.in', date: '2026-10-02', status: 'Approved' },
  { id: 'a6', name: 'Mr. J. Sunil', empId: 'RVR9999', dept: 'Mech', designation: 'Internship Coordinator', email: 'jsunil@rvrjc.ac.in', date: '2026-09-30', status: 'Rejected', note: 'Employee ID not found in HR records.' },
]

/* ------------------------- Departments & setup ------------------------- */

export type Branch = { code: string; name: string; students: number; archived: boolean }
export type Section = { id: string; branch: string; year: number; name: string; archived: boolean }
export type AcademicYear = { id: string; label: string; current: boolean; archived: boolean }

export const branchesSeed: Branch[] = [
  { code: 'CSE', name: 'Computer Science & Engineering', students: 720, archived: false },
  { code: 'IT', name: 'Information Technology', students: 360, archived: false },
  { code: 'ECE', name: 'Electronics & Communication', students: 480, archived: false },
  { code: 'EEE', name: 'Electrical & Electronics', students: 240, archived: false },
  { code: 'Mech', name: 'Mechanical Engineering', students: 240, archived: false },
  { code: 'Civil', name: 'Civil Engineering', students: 180, archived: false },
  { code: 'AI&ML', name: 'Artificial Intelligence & ML', students: 180, archived: false },
  { code: 'Chem', name: 'Chemical Engineering', students: 0, archived: true },
]

export const sectionsSeed: Section[] = BRANCHES.flatMap((b) =>
  YEARS.flatMap((y) => (b === 'CSE' || b === 'ECE' ? SECTIONS : b === 'IT' ? ['A', 'B'] : ['A']).map((s) => ({ id: `${b}-${y}-${s}`, branch: b, year: y, name: s, archived: false }))),
)

export const academicYearsSeed: AcademicYear[] = [
  { id: 'ay1', label: '2026–27', current: true, archived: false },
  { id: 'ay2', label: '2025–26', current: false, archived: false },
  { id: 'ay3', label: '2024–25', current: false, archived: true },
]

/* -------------------------- Roles & permissions -------------------------- */

export const PERMISSIONS = [
  { key: 'verify', label: 'Verify documents' },
  { key: 'post', label: 'Post opportunities' },
  { key: 'announce', label: 'Send announcements' },
  { key: 'export', label: 'Export reports' },
  { key: 'manage', label: 'Manage users' },
] as const
export type PermKey = (typeof PERMISSIONS)[number]['key']

export type RoleDef = { id: string; name: string; users: number; locked?: boolean; perms: Record<PermKey, boolean> }

export const rolesSeed: RoleDef[] = [
  { id: 'r1', name: 'Admin', users: 2, locked: true, perms: { verify: true, post: true, announce: true, export: true, manage: true } },
  { id: 'r2', name: 'Faculty Coordinator', users: 4, perms: { verify: true, post: true, announce: true, export: true, manage: false } },
  { id: 'r3', name: 'Faculty Mentor', users: 3, perms: { verify: true, post: false, announce: false, export: false, manage: false } },
  { id: 'r4', name: 'Reviewer', users: 3, perms: { verify: true, post: false, announce: false, export: true, manage: false } },
]

/* ------------------------ Internships & companies ------------------------ */

export type ListingSource = 'College' | 'Self-Found' | 'Referral'
export type ListingStatus = 'Open' | 'Closed'
export type Listing = { id: string; role: string; company: string; source: ListingSource; branches: string[]; deadline: string; status: ListingStatus; applicants: number }

const srcMap = { 'College Opportunity': 'College', 'Self-Found': 'Self-Found', 'Senior Referral': 'Referral' } as const

export const listingsSeed: Listing[] = [
  ...internships.map((i, n) => ({ id: i.id, role: i.role, company: i.company, source: srcMap[i.source] as ListingSource, branches: i.branches.map((b) => (b === 'Mechanical' ? 'Mech' : b)), deadline: i.deadline, status: 'Open' as ListingStatus, applicants: 18 + n * 11 })),
  { id: 'i7', role: 'Cloud Support Intern', company: 'Amazon Web Services', source: 'Self-Found', branches: ['CSE', 'IT'], deadline: '2026-11-12', status: 'Open', applicants: 9 },
  { id: 'i8', role: 'Work-from-home Data Entry', company: 'QuickHire Solutions', source: 'Referral', branches: ['CSE', 'IT', 'ECE'], deadline: '2026-10-15', status: 'Open', applicants: 4 },
  { id: 'i9', role: 'Power Systems Intern', company: 'APTRANSCO', source: 'College', branches: ['EEE'], deadline: '2026-09-28', status: 'Closed', applicants: 22 },
  { id: 'i10', role: 'Cybersecurity Analyst Intern', company: 'Tata Consultancy Services', source: 'College', branches: ['CSE', 'IT', 'AI&ML'], deadline: '2026-11-20', status: 'Open', applicants: 31 },
]

export type CompanyLabel = 'Trusted' | 'Neutral' | 'Blocked'
export type Company = { name: string; label: CompanyLabel; note: string }

export const companiesSeed: Company[] = [
  { name: 'Infosys', label: 'Trusted', note: 'MoU partner since 2019.' },
  { name: 'Zoho Corporation', label: 'Trusted', note: 'Regular campus recruiter.' },
  { name: 'ISRO – SDSC SHAR', label: 'Trusted', note: 'Government research centre.' },
  { name: 'Tata Consultancy Services', label: 'Trusted', note: 'MoU partner.' },
  { name: 'Swiggy', label: 'Neutral', note: '' },
  { name: 'L&T Construction', label: 'Trusted', note: 'Civil site internships every summer.' },
  { name: 'Amazon Web Services', label: 'Neutral', note: '' },
  { name: 'QuickHire Solutions', label: 'Blocked', note: 'Asked students for a registration fee. Reported twice.' },
  { name: 'APTRANSCO', label: 'Trusted', note: 'State power utility.' },
]

/* ------------------------------ Moderation ------------------------------ */

export type ModState = 'Reported' | 'Pending review' | 'Resolved'
export type ModDecision = 'Approved' | 'Removed' | 'Author warned' | 'Sharing suspended'
export type ModItem = {
  id: string
  kind: 'Experience' | 'Referral' | 'Comment'
  title: string
  content: string
  author: string
  authorHistory: { posts: number; warnings: number; removed: number }
  reason: string
  reporter?: string
  date: string
  state: ModState
  decision?: ModDecision
  note?: string
}

export const moderationSeed: ModItem[] = [
  { id: 'm1', kind: 'Experience', title: 'Experience: Zoho Frontend Intern', content: 'Two rounds — a take-home React task and a live coding round on DOM manipulation. Mentors were helpful; I worked on the Zoho Desk ticket view. Tip: revise CSS layout and event delegation.', author: 'Sai Kiran M. (Y22CS061)', authorHistory: { posts: 3, warnings: 0, removed: 0 }, reason: 'New post awaiting review', date: '2026-10-07', state: 'Pending review' },
  { id: 'm2', kind: 'Experience', title: 'Experience: Unknown Startup', content: 'Best internship ever!! DM me on Instagram @growfast.careers to get a guaranteed offer with 100% placement. Limited seats.', author: 'Anonymous', authorHistory: { posts: 1, warnings: 0, removed: 0 }, reason: 'Reported as promotional', reporter: 'Y23CS042', date: '2026-10-06', state: 'Reported' },
  { id: 'm3', kind: 'Referral', title: 'Referral: Paid internship ad', content: 'QuickHire is hiring data entry interns. Pay ₹1,499 registration and start tomorrow. Certificate guaranteed.', author: 'Y24CS201', authorHistory: { posts: 2, warnings: 1, removed: 1 }, reason: 'Possible scam — asks for payment', reporter: 'Dr. P. Lakshmi', date: '2026-10-06', state: 'Reported' },
  { id: 'm4', kind: 'Comment', title: 'Comment on: TCS Data Analyst', content: 'This is useless, only toppers get selected anyway, nobody should bother.', author: 'Y23IT033', authorHistory: { posts: 12, warnings: 0, removed: 0 }, reason: 'Discouraging / off-topic', reporter: 'Y23IT019', date: '2026-10-05', state: 'Reported' },
  { id: 'm5', kind: 'Experience', title: 'Experience: Infosys SE Intern', content: 'Worked on Finacle microservices. Interview was mostly Java OOP and SQL joins.', author: 'Harika Naidu (Y22CS045)', authorHistory: { posts: 2, warnings: 0, removed: 0 }, reason: 'New post awaiting review', date: '2026-10-04', state: 'Pending review' },
  { id: 'm6', kind: 'Referral', title: 'Referral: Fake MNC offer', content: 'Offer letters available for any company, contact on WhatsApp.', author: 'Y24EC118', authorHistory: { posts: 1, warnings: 0, removed: 1 }, reason: 'Fraudulent offer letters', reporter: 'Y23EC021', date: '2026-10-01', state: 'Resolved', decision: 'Removed', note: 'Clear fraud. Removed and author sharing suspended for 60 days.' },
]

/* ---------------------------- Announcements ---------------------------- */

export type AnnouncementStatus = 'Sent' | 'Scheduled' | 'Draft'
export type AdminAnnouncement = { id: string; title: string; body: string; link?: string; audience: string; recipients: number; status: AnnouncementStatus; date: string; delivered?: number; opened?: number }

export const announcementsSeed: AdminAnnouncement[] = [
  { id: 'an1', title: 'Summer internship drive — registrations open', body: 'Register on InternHub by 15 Oct to be considered for the summer drive.', link: 'https://rvrjc.ac.in/placements', audience: 'Students · All branches · Years 3, 4', recipients: 1200, status: 'Sent', date: '2026-10-03 10:00', delivered: 1188, opened: 842 },
  { id: 'an2', title: 'Verification SLA reminder for coordinators', body: 'Please clear pending verifications older than 3 days.', audience: 'Faculty · Internship Coordinators', recipients: 18, status: 'Sent', date: '2026-10-01 09:30', delivered: 18, opened: 16 },
  { id: 'an3', title: 'Resume clinic this Saturday', body: 'T&P cell will review resumes in Seminar Hall 2, 10 AM onwards.', audience: 'Students · CSE, IT · Year 3', recipients: 360, status: 'Scheduled', date: '2026-10-10 08:00' },
]

/* ------------------------------ Audit logs ------------------------------ */

export type AuditCategory = 'Verification' | 'Opportunity' | 'Settings' | 'Moderation' | 'User management' | 'Announcement'
export type AuditEntry = { id: string; actor: string; action: string; category: AuditCategory; target: string; time: string; before?: Record<string, string>; after?: Record<string, string> }

const cats: AuditCategory[] = ['Verification', 'Opportunity', 'Settings', 'Verification', 'Moderation']
export const auditSeed: AuditEntry[] = [
  ...auditLogs.map((l, i) => ({ ...l, category: cats[i] })),
  { id: 'l6', actor: 'Admin · M. Ravi', action: 'Approved faculty registration', category: 'User management', target: 'Dr. V. Usha Rani · RVR1075', time: '2026-10-02 12:10', before: { status: 'Pending' }, after: { status: 'Approved', role: 'Faculty Mentor' } },
  { id: 'l7', actor: 'Dr. N. Venkata Ramana', action: 'Requested additional proof', category: 'Verification', target: 'Y23EC021 · ISRO certificate', time: '2026-10-01 15:22' },
  { id: 'l8', actor: 'Admin · M. Ravi', action: 'Sent announcement', category: 'Announcement', target: 'Verification SLA reminder', time: '2026-10-01 09:30' },
].map((l) => (l.id === 'l3' ? { ...l, before: { 'Verification SLA': '5 days' }, after: { 'Verification SLA': '3 days' } } : l))

/* ------------------------------ Roadmaps ------------------------------ */

export type Roadmap = { id: string; role: string; skills: string[]; published: boolean }
export const roadmapsSeed: Roadmap[] = [
  { id: 'rm1', role: 'Data Analyst', skills: ['Excel', 'SQL', 'Python (Pandas)', 'Power BI', 'Statistics'], published: true },
  { id: 'rm2', role: 'Data Scientist', skills: ['Python', 'Statistics', 'Machine Learning', 'SQL', 'Model Deployment'], published: true },
  { id: 'rm3', role: 'Web Developer', skills: ['HTML & CSS', 'JavaScript', 'React', 'Node.js', 'Git'], published: true },
  { id: 'rm4', role: 'Python Developer', skills: ['Python', 'OOP', 'Django / Flask', 'REST APIs', 'Testing'], published: true },
  { id: 'rm5', role: 'AI/ML Engineer', skills: ['Linear Algebra', 'Python', 'Deep Learning', 'PyTorch', 'MLOps'], published: true },
  { id: 'rm6', role: 'Cloud Engineer', skills: ['Linux', 'Networking', 'AWS Core', 'Docker', 'Terraform'], published: false },
  { id: 'rm7', role: 'Cybersecurity Analyst', skills: ['Networking', 'Linux', 'OWASP Top 10', 'SIEM Tools', 'Incident Response'], published: true },
]

/* ------------------------------ Templates & support ------------------------------ */

export type TemplateKey = 'approved' | 'rejected' | 'moreinfo' | 'deadline'
export const templatesSeed: Record<TemplateKey, { label: string; subject: string; body: string }> = {
  approved: { label: 'Verification approved', subject: 'Your {document} has been verified', body: 'Hi {name},\n\n{faculty} has verified your {document} for {company}. It now appears on your verified internship record.\n\n— InternHub, {college}' },
  rejected: { label: 'Verification rejected', subject: 'Your {document} could not be verified', body: 'Hi {name},\n\n{faculty} could not verify your {document} for {company}.\nReason: {reason}\n\nYou can upload a corrected document from My Internships.' },
  moreinfo: { label: 'More information needed', subject: 'More information needed for {document}', body: 'Hi {name},\n\n{faculty} needs more information to verify your {document} for {company}:\n{reason}\n\nPlease respond within 5 days.' },
  deadline: { label: 'Deadline reminder', subject: '{company} applications close in {days} days', body: 'Hi {name},\n\nThe {role} internship at {company} closes on {deadline}. You are eligible — apply from InternHub before the deadline.' },
}

export const templateSample: Record<string, string> = { name: 'Ananya', document: 'offer letter', faculty: 'Dr. K. Srinivasa Rao', company: 'Infosys', reason: 'Company seal is not visible.', college: 'RVR&JC', days: '3', role: 'Software Engineering Intern', deadline: '18 Oct 2026' }

export type TicketStatus = 'Open' | 'In progress' | 'Closed'
export type Ticket = { id: string; from: string; role: 'Student' | 'Faculty'; subject: string; body: string; date: string; status: TicketStatus }
export const ticketsSeed: Ticket[] = [
  { id: 't1', from: 'Mohan Teja (Y23EC021)', role: 'Student', subject: 'Certificate upload fails on mobile', body: 'The upload spinner keeps loading when I pick a PDF from Google Drive.', date: '2026-10-07', status: 'Open' },
  { id: 't2', from: 'Dr. P. Lakshmi', role: 'Faculty', subject: 'Cannot see IT Year 2 students', body: 'My section list only shows Year 3 and 4.', date: '2026-10-06', status: 'In progress' },
  { id: 't3', from: 'Sneha L. (Y22CS088)', role: 'Student', subject: 'Wrong CGPA on profile', body: 'Profile shows 8.2, transcript says 8.7.', date: '2026-10-04', status: 'Open' },
  { id: 't4', from: 'Dr. S. Bhaskar', role: 'Faculty', subject: 'Export button greyed out', body: 'Reports export was disabled for me.', date: '2026-09-30', status: 'Closed' },
]

export type ScheduledReport = { id: string; name: string; frequency: 'Weekly' | 'Monthly'; recipients: string; active: boolean }
export const scheduledReportsSeed: ScheduledReport[] = [
  { id: 'sr1', name: 'Participation by branch', frequency: 'Monthly', recipients: 'principal@rvrjc.ac.in', active: true },
  { id: 'sr2', name: 'Verification turnaround by faculty', frequency: 'Weekly', recipients: 'tpo@rvrjc.ac.in', active: true },
]

export const facultyPerBranch: Record<string, number> = { CSE: 14, IT: 7, ECE: 9, EEE: 5, Mech: 5, Civil: 4, 'AI&ML': 4 }
export const branchStudents: Record<string, number> = Object.fromEntries(branchesSeed.map((b) => [b.code, b.students]))
