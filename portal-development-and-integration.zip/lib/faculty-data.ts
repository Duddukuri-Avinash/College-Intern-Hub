import type { AppStatus, Mode, VerifyStatus } from '@/lib/data'

export const TODAY = '2026-10-07'

export const facultyAccount = {
  name: 'Dr. K. Srinivasa Rao',
  employeeId: 'RVR1043',
  dept: 'Department of CSE',
  designation: 'Internship Coordinator',
  email: 'ksrao.cse@rvrjc.ac.in',
  phone: '+91 94405 31872',
}

export const sections = ['3-A', '3-B', '3-C', '4-A', '4-B', '4-C'] as const
export const sectionSizes: Record<string, number> = { '3-A': 122, '3-B': 120, '3-C': 118, '4-A': 121, '4-B': 119, '4-C': 120 }

/* ------------------------------ Students ------------------------------ */

export type InternshipStatus = 'Not started' | 'Applied' | 'Ongoing' | 'Completed'
export type StudentVerification = VerifyStatus | 'No submissions'

export type DeptStudent = {
  id: string
  name: string
  regNo: string
  year: 3 | 4
  section: 'A' | 'B' | 'C'
  cgpa: number
  readiness: number
  status: InternshipStatus
  verification: StudentVerification
  skills: string[]
  email: string
  phone: string
  applications: { company: string; role: string; status: AppStatus; date: string }[]
  internships: { company: string; role: string; period: string; status: 'Ongoing' | 'Completed' }[]
  documents: { name: string; type: string; status: VerifyStatus; date: string }[]
  timeline: { date: string; event: string; by: string; status?: VerifyStatus }[]
}

type Row = [string, string, string, 3 | 4, 'A' | 'B' | 'C', number, number, InternshipStatus, StudentVerification, string[], string?, string?, string?]

const rows: Row[] = [
  ['s1', 'Ananya Reddy', 'Y23CS042', 3, 'A', 8.4, 72, 'Completed', 'Additional Proof Required', ['Java', 'Python', 'SQL', 'React'], 'Cognizant', 'Web Development Intern', '9848521436'],
  ['s2', 'Divya Sri K.', 'Y23CS110', 3, 'B', 8.9, 81, 'Ongoing', 'Pending', ['Go', 'PostgreSQL', 'Docker'], 'Razorpay', 'Backend Intern', '9912204518'],
  ['s3', 'Sneha L.', 'Y22CS088', 4, 'A', 8.1, 76, 'Completed', 'Pending', ['Excel', 'SQL', 'Power BI'], 'Accenture', 'Analyst Intern', '9701843306'],
  ['s4', 'Karthik N.', 'Y23CS015', 3, 'A', 7.2, 48, 'Not started', 'No submissions', ['C', 'Python'], undefined, undefined, '9640017725'],
  ['s5', 'Lakshmi Prasanna B.', 'Y23CS067', 3, 'C', 7.8, 59, 'Applied', 'No submissions', ['Java', 'HTML', 'CSS'], undefined, undefined, '9866451290'],
  ['s6', 'Pavan Kalyan T.', 'Y22CS031', 4, 'B', 8.6, 84, 'Ongoing', 'Verified', ['Java', 'AWS', 'DSA'], 'Amazon', 'SDE Intern', '9490376614'],
  ['s7', 'Meghana V.', 'Y22CS119', 4, 'C', 9.1, 88, 'Completed', 'Verified', ['Python', 'PyTorch', 'NLP'], 'Microsoft', 'Research Intern', '9959023147'],
  ['s8', 'Rohit Chowdary G.', 'Y23CS093', 3, 'B', 6.8, 41, 'Not started', 'No submissions', ['C', 'HTML'], undefined, undefined, '9603318842'],
  ['s9', 'Sravani M.', 'Y23CS128', 3, 'C', 7.5, 55, 'Applied', 'No submissions', ['Python', 'Pandas'], undefined, undefined, '9347765021'],
  ['s10', 'Naveen Kumar P.', 'Y22CS052', 4, 'A', 7.9, 66, 'Ongoing', 'Verified', ['Python', 'Pandas', 'Tableau'], 'TCS', 'Data Analyst Intern', '9177250936'],
  ['s11', 'Bhavana Sai R.', 'Y22CS074', 4, 'B', 8.3, 70, 'Applied', 'Rejected', ['React', 'Node.js'], undefined, undefined, '9032184475'],
  ['s12', 'Teja Varma S.', 'Y23CS101', 3, 'A', 8.0, 63, 'Ongoing', 'Pending', ['React', 'TypeScript'], 'Zoho Corporation', 'Frontend Intern', '9885507213'],
  ['s13', 'Harsha Vardhan K.', 'Y22CS140', 4, 'C', 7.0, 45, 'Not started', 'No submissions', ['Java', 'SQL'], undefined, undefined, '9618843390'],
  ['s14', 'Keerthi Reddy A.', 'Y23CS036', 3, 'B', 8.7, 79, 'Completed', 'Verified', ['JavaScript', 'React', 'MongoDB'], 'Cognizant', 'Web Development Intern', '9550126684'],
]

const reviewer = 'Dr. K. Srinivasa Rao'

function buildStudent([id, name, regNo, year, section, cgpa, readiness, status, verification, skills, company, role, phone]: Row): DeptStudent {
  const email = `${name.split(' ')[0].toLowerCase()}.${regNo.toLowerCase()}@rvrjc.ac.in`
  const docStatus: VerifyStatus = verification === 'No submissions' ? 'Pending' : verification
  const applications: DeptStudent['applications'] = []
  const internships: DeptStudent['internships'] = []
  const documents: DeptStudent['documents'] = []
  const timeline: DeptStudent['timeline'] = []

  if (status === 'Applied') {
    applications.push(
      { company: 'Infosys', role: 'Software Engineering Intern', status: 'Interview', date: '2026-10-04' },
      { company: 'Tata Consultancy Services', role: 'Data Analyst Intern', status: 'Applied', date: '2026-10-02' },
    )
    if (verification === 'Rejected') {
      documents.push({ name: 'quickbuild_offer.pdf', type: 'Offer Letter', status: 'Rejected', date: '2026-09-24' })
      timeline.push(
        { date: '2026-09-24', event: 'Submitted self-found offer · QuickBuild Tech', by: name },
        { date: '2026-09-26', event: 'Offer rejected — company could not be verified', by: reviewer, status: 'Rejected' },
      )
    }
  }
  if (status === 'Not started') applications.push({ company: 'Tech Mahindra', role: 'Network Engineering Intern', status: 'Saved', date: '2026-10-01' })

  if ((status === 'Ongoing' || status === 'Completed') && company && role) {
    applications.push({ company, role, status: 'Selected', date: status === 'Ongoing' ? '2026-07-12' : '2026-04-02' }, { company: 'Wipro', role: 'Cloud Intern', status: 'Rejected', date: '2026-03-18' })
    internships.push({ company, role, period: status === 'Ongoing' ? 'Aug 2026 – Nov 2026' : 'May 2026 – Jul 2026', status })
    if (status === 'Ongoing') {
      documents.push({ name: `${company.split(' ')[0].toLowerCase()}_offer_letter.pdf`, type: 'Offer Letter', status: docStatus, date: '2026-09-29' })
      timeline.push({ date: '2026-09-29', event: `Uploaded offer letter · ${company}`, by: name })
      if (docStatus !== 'Pending') timeline.push({ date: '2026-10-01', event: `Offer letter ${docStatus.toLowerCase()}`, by: reviewer, status: docStatus })
    } else {
      documents.push(
        { name: `${company.split(' ')[0].toLowerCase()}_offer_letter.pdf`, type: 'Offer Letter', status: 'Verified', date: '2026-04-05' },
        { name: `${company.split(' ')[0].toLowerCase()}_certificate.pdf`, type: 'Certificate', status: docStatus, date: '2026-09-30' },
      )
      timeline.push(
        { date: '2026-04-05', event: `Uploaded offer letter · ${company}`, by: name },
        { date: '2026-04-07', event: 'Offer letter verified', by: reviewer, status: 'Verified' },
        { date: '2026-09-30', event: 'Uploaded completion certificate', by: name },
      )
      if (docStatus !== 'Pending') timeline.push({ date: '2026-10-02', event: `Certificate ${docStatus.toLowerCase()}`, by: reviewer, status: docStatus })
    }
  }

  return {
    id, name, regNo, year, section, cgpa, readiness, status, verification, skills, email,
    phone: `+91 ${phone?.slice(0, 5)} ${phone?.slice(5)}`,
    applications, internships, documents,
    timeline: timeline.sort((a, b) => b.date.localeCompare(a.date)),
  }
}

export const deptStudents: DeptStudent[] = rows.map(buildStudent).map((s) =>
  s.id === 's1'
    ? {
        ...s,
        documents: [
          { name: 'cognizant_offer_letter.pdf', type: 'Offer Letter', status: 'Verified', date: '2026-04-05' },
          { name: 'cognizant_certificate.pdf', type: 'Certificate', status: 'Verified', date: '2026-08-02' },
          { name: 'swiggy_offer_letter.pdf', type: 'Offer Letter', status: 'Pending', date: '2026-10-06' },
        ],
        applications: [
          { company: 'Infosys', role: 'Software Engineering Intern', status: 'Interview', date: '2026-10-05' },
          { company: 'Zoho Corporation', role: 'Frontend Developer Intern', status: 'Applied', date: '2026-10-03' },
          { company: 'Swiggy', role: 'Machine Learning Intern', status: 'Selected', date: '2026-09-28' },
          { company: 'ISRO – SDSC SHAR', role: 'Embedded Systems Trainee', status: 'Rejected', date: '2026-09-20' },
        ],
        timeline: [
          { date: '2026-10-06', event: 'Re-uploaded Swiggy offer with HR email', by: 'Ananya Reddy' },
          { date: '2026-10-03', event: 'Additional proof requested — stipend not shown', by: reviewer, status: 'Additional Proof Required' },
          { date: '2026-10-01', event: 'Uploaded offer letter · Swiggy', by: 'Ananya Reddy' },
          { date: '2026-08-04', event: 'Cognizant certificate verified', by: 'Dr. P. Lakshmi', status: 'Verified' },
          { date: '2026-04-07', event: 'Cognizant offer letter verified', by: 'Dr. P. Lakshmi', status: 'Verified' },
        ],
      }
    : s,
)

/* --------------------------- Verification items --------------------------- */

export type AuditEntry = { action: string; by: string; date: string; note?: string; status?: VerifyStatus }

export type VerificationItem = {
  id: string
  type: 'Offer Letter' | 'Certificate' | 'Self-Found' | 'Experience'
  student: string
  regNo: string
  branch: string
  section: string
  company: string
  role: string
  submitted: string
  status: VerifyStatus
  file: string
  decidedBy?: string
  decidedOn?: string
  note?: string
  audit: AuditEntry[]
}

export const verificationItems: VerificationItem[] = [
  {
    id: 'v1', type: 'Offer Letter', student: 'Ananya Reddy', regNo: 'Y23CS042', branch: 'CSE', section: '3-A', company: 'Swiggy', role: 'ML Intern', submitted: '2026-10-06', status: 'Pending', file: 'swiggy_offer_letter.pdf',
    audit: [
      { action: 'Submitted', by: 'Ananya Reddy', date: '2026-10-01' },
      { action: 'Additional proof requested', by: reviewer, date: '2026-10-03', note: 'Offer letter does not show the stipend amount or reporting manager.', status: 'Additional Proof Required' },
      { action: 'Resubmitted with HR email', by: 'Ananya Reddy', date: '2026-10-06' },
    ],
  },
  { id: 'v2', type: 'Certificate', student: 'Rahul Varma', regNo: 'Y22IT017', branch: 'IT', section: '4-B', company: 'Wipro', role: 'Cloud Intern', submitted: '2026-10-05', status: 'Pending', file: 'wipro_certificate.pdf', audit: [{ action: 'Submitted', by: 'Rahul Varma', date: '2026-10-05' }] },
  { id: 'v3', type: 'Self-Found', student: 'Divya Sri K.', regNo: 'Y23CS110', branch: 'CSE', section: '3-B', company: 'Razorpay', role: 'Backend Intern', submitted: '2026-10-05', status: 'Pending', file: 'razorpay_offer.pdf', audit: [{ action: 'Submitted', by: 'Divya Sri K.', date: '2026-10-05' }] },
  { id: 'v4', type: 'Experience', student: 'Harika P.', regNo: 'Y21IT033', branch: 'IT', section: '4-A', company: 'Infosys', role: 'SE Intern', submitted: '2026-10-04', status: 'Pending', file: 'experience_writeup', audit: [{ action: 'Submitted', by: 'Harika P.', date: '2026-10-04' }] },
  {
    id: 'v5', type: 'Offer Letter', student: 'Mohan Teja', regNo: 'Y23EC021', branch: 'ECE', section: '3-C', company: 'Qualcomm', role: 'VLSI Intern', submitted: '2026-10-01', status: 'Additional Proof Required', file: 'qualcomm_offer.pdf',
    decidedBy: 'Dr. S. Bhaskar', decidedOn: '2026-10-03', note: 'Letter lacks a company seal. Upload the offer email from the Qualcomm HR domain.',
    audit: [
      { action: 'Submitted', by: 'Mohan Teja', date: '2026-10-01' },
      { action: 'Additional proof requested', by: 'Dr. S. Bhaskar', date: '2026-10-03', note: 'Letter lacks a company seal. Upload the offer email from the Qualcomm HR domain.', status: 'Additional Proof Required' },
    ],
  },
  { id: 'v6', type: 'Certificate', student: 'Sneha L.', regNo: 'Y22CS088', branch: 'CSE', section: '4-A', company: 'Accenture', role: 'Analyst Intern', submitted: '2026-09-30', status: 'Pending', file: 'accenture_cert.pdf', audit: [{ action: 'Submitted', by: 'Sneha L.', date: '2026-09-30' }] },
  { id: 'v7', type: 'Offer Letter', student: 'Teja Varma S.', regNo: 'Y23CS101', branch: 'CSE', section: '3-A', company: 'Zoho Corporation', role: 'Frontend Intern', submitted: '2026-09-29', status: 'Pending', file: 'zoho_offer_letter.pdf', audit: [{ action: 'Submitted', by: 'Teja Varma S.', date: '2026-09-29' }] },
  { id: 'v8', type: 'Self-Found', student: 'Sai Charan D.', regNo: 'Y23IT058', branch: 'IT', section: '3-B', company: 'Freshworks', role: 'QA Intern', submitted: '2026-10-02', status: 'Pending', file: 'freshworks_offer.pdf', audit: [{ action: 'Submitted', by: 'Sai Charan D.', date: '2026-10-02' }] },
  {
    id: 'v9', type: 'Certificate', student: 'Keerthi Reddy A.', regNo: 'Y23CS036', branch: 'CSE', section: '3-B', company: 'Cognizant', role: 'Web Dev Intern', submitted: '2026-09-29', status: 'Verified', file: 'cognizant_certificate.pdf',
    decidedBy: reviewer, decidedOn: '2026-10-01', note: 'Certificate matches HR records.',
    audit: [{ action: 'Submitted', by: 'Keerthi Reddy A.', date: '2026-09-29' }, { action: 'Verified', by: reviewer, date: '2026-10-01', note: 'Certificate matches HR records.', status: 'Verified' }],
  },
  {
    id: 'v10', type: 'Offer Letter', student: 'Pavan Kalyan T.', regNo: 'Y22CS031', branch: 'CSE', section: '4-B', company: 'Amazon', role: 'SDE Intern', submitted: '2026-09-22', status: 'Verified', file: 'amazon_offer.pdf',
    decidedBy: reviewer, decidedOn: '2026-09-24', note: 'Verified via amazon.jobs offer portal screenshot and HR email.',
    audit: [{ action: 'Submitted', by: 'Pavan Kalyan T.', date: '2026-09-22' }, { action: 'Verified', by: reviewer, date: '2026-09-24', note: 'Verified via amazon.jobs offer portal screenshot and HR email.', status: 'Verified' }],
  },
  {
    id: 'v11', type: 'Self-Found', student: 'Bhavana Sai R.', regNo: 'Y22CS074', branch: 'CSE', section: '4-B', company: 'QuickBuild Tech', role: 'Full Stack Intern', submitted: '2026-09-24', status: 'Rejected', file: 'quickbuild_offer.pdf',
    decidedBy: reviewer, decidedOn: '2026-09-26', note: 'Company not registered with MCA and HR contact unreachable. Please apply through verified channels.',
    audit: [{ action: 'Submitted', by: 'Bhavana Sai R.', date: '2026-09-24' }, { action: 'Rejected', by: reviewer, date: '2026-09-26', note: 'Company not registered with MCA and HR contact unreachable.', status: 'Rejected' }],
  },
  {
    id: 'v12', type: 'Certificate', student: 'Meghana V.', regNo: 'Y22CS119', branch: 'CSE', section: '4-C', company: 'Microsoft', role: 'Research Intern', submitted: '2026-09-16', status: 'Verified', file: 'microsoft_certificate.pdf',
    decidedBy: 'Dr. P. Lakshmi', decidedOn: '2026-09-18', note: 'Signed by MSR India program manager.',
    audit: [{ action: 'Submitted', by: 'Meghana V.', date: '2026-09-16' }, { action: 'Verified', by: 'Dr. P. Lakshmi', date: '2026-09-18', note: 'Signed by MSR India program manager.', status: 'Verified' }],
  },
  {
    id: 'v13', type: 'Experience', student: 'Naveen Kumar P.', regNo: 'Y22CS052', branch: 'CSE', section: '4-A', company: 'TCS', role: 'Data Analyst Intern', submitted: '2026-09-12', status: 'Verified', file: 'experience_writeup',
    decidedBy: reviewer, decidedOn: '2026-09-15', note: 'Experience post approved for Learn from Seniors.',
    audit: [{ action: 'Submitted', by: 'Naveen Kumar P.', date: '2026-09-12' }, { action: 'Verified', by: reviewer, date: '2026-09-15', note: 'Experience post approved for Learn from Seniors.', status: 'Verified' }],
  },
]

/** Working days (Mon–Fri) elapsed after `from` up to and including TODAY. */
export function workingDaysSince(from: string) {
  const start = new Date(from)
  const end = new Date(TODAY)
  let days = 0
  const d = new Date(start)
  while (d < end) {
    d.setDate(d.getDate() + 1)
    const day = d.getDay()
    if (day !== 0 && day !== 6) days++
  }
  return days
}

export const SLA_DAYS = 3

/* ------------------------------ Opportunities ------------------------------ */

export type OppStatus = 'Draft' | 'Active' | 'Closed'

export type Opportunity = {
  id: string
  company: string
  role: string
  duration: string
  mode: Mode
  stipend: string
  deadline: string
  skills: string
  description: string
  link: string
  branches: string[]
  years: number[]
  minCgpa: number
  status: OppStatus
  eligible: number
  interested: string[]
  postedOn: string
}

export const opportunitiesSeed: Opportunity[] = [
  { id: 'o1', company: 'Infosys', role: 'Software Engineering Intern', duration: '8 weeks', mode: 'Hybrid', stipend: '15000', deadline: '2026-10-18', skills: 'Java, Spring Boot, SQL', description: 'Backend microservices on the Finacle platform with mentorship from senior engineers.', link: 'https://www.infosys.com/careers', branches: ['CSE', 'IT', 'CSBS'], years: [3, 4], minCgpa: 7, status: 'Active', eligible: 214, interested: ['s1', 's2', 's5', 's9', 's12'], postedOn: '2026-09-25' },
  { id: 'o2', company: 'Tata Consultancy Services', role: 'Data Analyst Intern', duration: '10 weeks', mode: 'Remote', stipend: '12000', deadline: '2026-10-30', skills: 'Python, Pandas, Power BI', description: 'Analyse operational datasets for a banking client and build KPI dashboards.', link: 'https://www.tcs.com/careers', branches: ['CSE', 'IT', 'CSBS', 'AI&ML'], years: [2, 3, 4], minCgpa: 6, status: 'Active', eligible: 386, interested: ['s5', 's9', 's10', 's4'], postedOn: '2026-09-28' },
  { id: 'o3', company: 'Tech Mahindra', role: 'Network Engineering Intern', duration: '6 weeks', mode: 'On-site', stipend: '8000', deadline: '2026-10-09', skills: 'Networking, Linux, CCNA', description: 'Hands-on exposure to enterprise network operations at the Hyderabad NOC.', link: 'https://careers.techmahindra.com', branches: ['CSE', 'IT', 'ECE'], years: [3, 4], minCgpa: 6.5, status: 'Active', eligible: 248, interested: ['s4', 's13'], postedOn: '2026-09-30' },
  { id: 'o4', company: 'Wipro', role: 'Cloud Engineering Intern', duration: '12 weeks', mode: 'Hybrid', stipend: '18000', deadline: '2026-11-10', skills: 'AWS, Linux, Python', description: 'Work with the cloud migration team on infrastructure automation.', link: 'https://careers.wipro.com', branches: ['CSE', 'IT'], years: [4], minCgpa: 7.5, status: 'Draft', eligible: 96, interested: [], postedOn: '2026-10-06' },
  { id: 'o5', company: 'HCLTech', role: 'Software Testing Intern', duration: '8 weeks', mode: 'On-site', stipend: '10000', deadline: '2026-09-20', skills: 'Selenium, Java, Manual testing', description: 'Functional and automation testing for a healthcare product line.', link: 'https://www.hcltech.com/careers', branches: ['CSE', 'IT'], years: [3, 4], minCgpa: 6, status: 'Closed', eligible: 240, interested: ['s8', 's13', 's11'], postedOn: '2026-09-02' },
]

/* ------------------------------ Requests ------------------------------ */

export type RequestType = 'Permission / NOC letter' | 'Completion certificate letter' | 'Re-verification request' | 'Query to faculty'
export type RequestStatus = 'New' | 'In progress' | 'Resolved'

export type StudentRequest = {
  id: string
  studentId: string
  student: string
  regNo: string
  section: string
  type: RequestType
  date: string
  status: RequestStatus
  subject: string
  message: string
  decision?: 'Approved' | 'Rejected'
  reason?: string
  thread: { by: string; text: string; date: string; faculty?: boolean }[]
}

export const requestsSeed: StudentRequest[] = [
  { id: 'r1', studentId: 's4', student: 'Karthik N.', regNo: 'Y23CS015', section: '3-A', type: 'Permission / NOC letter', date: '2026-10-07', status: 'New', subject: 'NOC for Tech Mahindra internship', message: 'Respected sir, Tech Mahindra requires a No Objection Certificate from the college to process my internship application. The internship runs Nov 10 – Dec 20 and does not overlap with semester exams. Kindly issue the NOC.', thread: [] },
  { id: 'r2', studentId: 's3', student: 'Sneha L.', regNo: 'Y22CS088', section: '4-A', type: 'Completion certificate letter', date: '2026-10-06', status: 'New', subject: 'College letter confirming Accenture internship completion', message: 'I have completed my internship at Accenture and uploaded the certificate. I need a college letter confirming completion for my credit transfer form.', thread: [] },
  { id: 'r3', studentId: 's2', student: 'Divya Sri K.', regNo: 'Y23CS110', section: '3-B', type: 'Re-verification request', date: '2026-10-06', status: 'New', subject: 'Updated Razorpay offer letter', message: 'Razorpay sent a revised offer with the corrected start date. Please re-verify my self-found internship with the new document.', thread: [] },
  {
    id: 'r4', studentId: 's9', student: 'Sravani M.', regNo: 'Y23CS128', section: '3-C', type: 'Query to faculty', date: '2026-10-05', status: 'In progress', subject: 'Can a remote internship count for credits?', message: 'Sir, does a fully remote internship count towards the mandatory internship credits for 3rd year?',
    thread: [{ by: 'Dr. K. Srinivasa Rao', text: 'Yes, remote internships count if the duration is at least 6 weeks. I am confirming the weekly hours requirement with the HoD and will update you.', date: '2026-10-06', faculty: true }],
  },
  { id: 'r5', studentId: 's6', student: 'Pavan Kalyan T.', regNo: 'Y22CS031', section: '4-B', type: 'Permission / NOC letter', date: '2026-10-01', status: 'Resolved', decision: 'Approved', subject: 'NOC for Amazon SDE internship', message: 'Requesting an NOC for my Amazon internship starting Aug 2026.', thread: [{ by: 'Dr. K. Srinivasa Rao', text: 'NOC approved and sent to your college email.', date: '2026-10-02', faculty: true }] },
  { id: 'r6', studentId: 's11', student: 'Bhavana Sai R.', regNo: 'Y22CS074', section: '4-B', type: 'Re-verification request', date: '2026-09-28', status: 'Resolved', decision: 'Rejected', reason: 'No new evidence provided. The company is still not verifiable.', subject: 'Please re-check QuickBuild offer', message: 'My QuickBuild Tech offer was rejected. Could you please check again?', thread: [{ by: 'Dr. K. Srinivasa Rao', text: 'No new evidence provided. The company is still not verifiable.', date: '2026-09-29', faculty: true }] },
]

/* ------------------------------ Announcements ------------------------------ */

export type Announcement = { id: string; title: string; body: string; audience: string; deadline?: string; sentOn: string; delivered: number; read: number }

export const announcementsSeed: Announcement[] = [
  { id: 'an1', title: 'Infosys pre-placement talk on Oct 12', body: 'All 3rd-year students eligible for the Infosys SE Intern role must attend the pre-placement talk in Seminar Hall 2 at 10:00 AM.', audience: 'Year 3 · All sections', sentOn: '2026-10-04', delivered: 360, read: 287 },
  { id: 'an2', title: 'Submit internship certificates before Oct 31', body: 'Students who completed summer internships must upload their completion certificates on InternHub for faculty verification.', audience: 'All eligible students', deadline: '2026-10-31', sentOn: '2026-09-30', delivered: 720, read: 604 },
  { id: 'an3', title: 'NOC request window for Section 4-B', body: 'Submit NOC requests for winter internships through the Requests section by Oct 15.', audience: 'Year 4 · Section B', deadline: '2026-10-15', sentOn: '2026-09-27', delivered: 119, read: 82 },
]

/* ------------------------------ Reports ------------------------------ */

export const sectionReport = [
  { section: '3-A', students: 122, participated: 71, verified: 60, pending: 8 },
  { section: '3-B', students: 120, participated: 66, verified: 55, pending: 7 },
  { section: '3-C', students: 118, participated: 58, verified: 47, pending: 9 },
  { section: '4-A', students: 121, participated: 102, verified: 94, pending: 5 },
  { section: '4-B', students: 119, participated: 97, verified: 88, pending: 6 },
  { section: '4-C', students: 120, participated: 104, verified: 97, pending: 4 },
]

export const domainReport = [
  { label: 'Software Development', value: 182 },
  { label: 'Data & Analytics', value: 96 },
  { label: 'AI / Machine Learning', value: 64 },
  { label: 'Cloud & DevOps', value: 48 },
  { label: 'Cybersecurity', value: 22 },
  { label: 'Embedded / Core', value: 16 },
  { label: 'Product & Design', value: 10 },
]

export const companyReport = [
  { label: 'Tata Consultancy Services', value: 58 },
  { label: 'Infosys', value: 52 },
  { label: 'Accenture', value: 41 },
  { label: 'Cognizant', value: 37 },
  { label: 'Wipro', value: 29 },
  { label: 'Zoho Corporation', value: 18 },
  { label: 'Amazon', value: 9 },
  { label: 'Razorpay', value: 6 },
]

export const stipendReport = [
  { label: 'Unpaid', value: 84 },
  { label: '₹1k – ₹10k', value: 126 },
  { label: '₹10k – ₹20k', value: 158 },
  { label: '₹20k – ₹40k', value: 92 },
  { label: '₹40k+', value: 38 },
]
